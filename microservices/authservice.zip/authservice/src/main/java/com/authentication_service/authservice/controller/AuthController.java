package com.authentication_service.authservice.controller;

import com.authentication_service.authservice.dto.AuthUserDTO;
import com.authentication_service.authservice.entity.AuthUserEntity;
import com.authentication_service.authservice.service.AuthService;
import com.authentication_service.authservice.util.JWTUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/request/auth")
public class AuthController {
    @Autowired
    private JWTUtil jwtUtil;

//    String email = "random@gmail.com";
//    String role = "ADMIN";

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthService authService;

    //Generate token
    @GetMapping("/token")
    public Map<String, String> generateToken(@RequestParam String email, @RequestParam String role){
        String token = jwtUtil.generateToken(email, role);
        return Map.of("token", token);
    }

    //Validate token and extract claims
    @GetMapping("/validate")
    public Map<String, Object> validateToken(@RequestParam String email, @RequestParam String token){
        boolean isValid = jwtUtil.validateToken(token,email);
        String role = jwtUtil.extractRole(token);
        String issuedAt = jwtUtil.extractIssuedAt(token).toString();
        String expiration = jwtUtil.extractExpiration(token).toString();

        return Map.of(
                "isValid", isValid,
                "email", email,
                "role", role,
                "issuedAt",issuedAt,
                "expiration", expiration
        );
    }

    //Register new user
    @PostMapping("/signup")
    public Map<String, String> registerUser(@RequestBody AuthUserDTO userDTO){
        return Map.of("Message", authService.registerUser(userDTO));
    }

    //Login Existing user and return jwt token
    @PostMapping("/login")
    public Map<String,Object> login(@RequestBody AuthUserDTO userDTO){
        return authService.login(userDTO);
    }

}
