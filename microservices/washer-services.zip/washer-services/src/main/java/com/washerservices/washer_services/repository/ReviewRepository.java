package com.washerservices.washer_services.repository;

import com.washerservices.washer_services.entity.ReviewEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<ReviewEntity, Long> {
    List<ReviewEntity> findByWasherId(String washerId);
}
