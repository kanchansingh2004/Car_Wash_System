package com.washerservices.washer_services.services.review;

import com.washerservices.washer_services.dto.ReviewDTO;

import java.util.List;

public interface ReviewService {
    ReviewDTO addReview(ReviewDTO reviewDTO);
    List<ReviewDTO> getReviewsForWasher(String washerId);
}
