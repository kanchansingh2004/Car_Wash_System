package com.washerservices.washer_services.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WashRequestDTO {
    private String bookingId;
    private String washerId;
    private String customerId;
    private String carId;
    private String customerName;
    private String packageName;
    private String serviceType;
    private String scheduledTime;
    private String address;
    private String status; // e.g. PENDING, ACCEPTED, DECLINED, IN_PROGRESS, COMPLETED
}
