package com.washerservices.washer_services.controller;

import com.washerservices.washer_services.dto.ReviewDTO;
import com.washerservices.washer_services.services.review.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("request/washer/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    // Post a new review
    @PostMapping("/addReview")
    public ResponseEntity<ReviewDTO> addReview(@RequestBody ReviewDTO reviewDTO) {
        return new ResponseEntity<>(reviewService.addReview(reviewDTO), HttpStatus.CREATED);
    }

    // Get all reviews for a washer
    @GetMapping("/getReview/{washerId}")
    public ResponseEntity<List<ReviewDTO>> getReviews(@PathVariable String washerId) {
        return ResponseEntity.ok(reviewService.getReviewsForWasher(washerId));
    }
}
