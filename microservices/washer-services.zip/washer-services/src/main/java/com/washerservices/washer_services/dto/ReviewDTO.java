package com.washerservices.washer_services.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDTO {
    private String washerId;
    private String comment;
    private int rating;
}
