package com.washerservices.washer_services.services.washer;

import com.customer_service.customerservices.dto.BookingDTO;
import com.washerservices.washer_services.dto.UpdateProfileDTO;
import com.washerservices.washer_services.dto.WashRequestDTO;
import com.washerservices.washer_services.dto.WasherDTO;
import com.washerservices.washer_services.entity.WasherEntity;
import com.washerservices.washer_services.exceptionhandling.AlreadyPresentException;
import com.washerservices.washer_services.exceptionhandling.NotFoundException;
import com.washerservices.washer_services.repository.WasherRepository;
import com.washerservices.washer_services.util.AuthClientCall;
import com.washerservices.washer_services.util.BookingClientCall;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
@Service
public class WasherServicesImp implements WasherService {
    @Autowired private WasherRepository washerRepo;
    @Autowired private AuthClientCall client;
    @Autowired private ModelMapper modelMapper; // ModelMapper for DTO conversion
    @Autowired private BookingClientCall bookingClientCall;

    private static final Logger log = LoggerFactory.getLogger(WasherServicesImp.class);

    private final Map<String, WashRequestDTO> washRequests = new ConcurrentHashMap<>();

    public Map<String, List<BookingDTO>> getWasherBookings(String washerId) {
        return bookingClientCall.getBookingsForWasher(washerId);
    }

    @Override
    public List<WasherDTO> getAllWasher() {
        log.info("Fetching all users from the database.");
        List<WasherEntity>  users = washerRepo.findAll();
        return users.stream()
                .map(user -> modelMapper.map(user, WasherDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public WasherDTO addWasher(String email, String profileImage) throws AlreadyPresentException, NotFoundException {
        // 1. Get profile from Auth Service
        WasherDTO authProfile = client.getWasherProfile(email);
        if (authProfile == null) {
            throw new NotFoundException("Washer not found");
        }

        if(washerRepo.findByEmail(email).isPresent()){
            throw new AlreadyPresentException("Washer is already registered!!");
        }

        // 2. Combine with profileImage
        WasherDTO washerDTO = new WasherDTO();
        washerDTO.setEmail(authProfile.getEmail());
        washerDTO.setFirstName(authProfile.getFirstName());
        washerDTO.setLastName(authProfile.getLastName());
        washerDTO.setProfileImage(profileImage); // From request body
        washerDTO.setAddress(authProfile.getAddress());
        washerDTO.setPhone(authProfile.getPhone());
        washerDTO.setRole(authProfile.getRole());
        washerDTO.setUserId(authProfile.getUserId());
        // 3. Save to Washer DB (if needed)
        // Completely customize the type map
        TypeMap<WasherDTO, WasherEntity> typeMap = modelMapper.typeMap(WasherDTO.class, WasherEntity.class);

// Skip auto-mapping of 'id' to avoid Long/String conflict
        typeMap.addMappings(mapper -> {
            mapper.skip(WasherEntity::setId); // prevent mapping to 'id'
            mapper.map(WasherDTO::getUserId, WasherEntity::setUserId);
        });

        WasherEntity entity = modelMapper.map(washerDTO, WasherEntity.class);
        entity.setProfileImage(profileImage);
        washerRepo.save(entity);

        return washerDTO;
    }

    @Override
    public UpdateProfileDTO updateWasher(String id, UpdateProfileDTO userDTO) {
        return washerRepo.findByUserId(id).map(entity -> {
            entity.setFirstName(userDTO.getFirstName());
            entity.setLastName(userDTO.getLastName());
            entity.setPhone(userDTO.getPhone());
            entity.setAddress(userDTO.getAddress());
            entity.setEmail(userDTO.getEmail());
            entity.setProfileImage(userDTO.getProfileImage());
            WasherEntity updatedEntity = washerRepo.save(entity);
            log.info("Employee details updated for ID: {}", id);
            return modelMapper.map(updatedEntity, UpdateProfileDTO.class); // Mapping entity to DTO
        }).orElse(null);
    }

    @Override
    public void deleteWasher(String id){
        WasherEntity dto = washerRepo.findByUserId(id).get();
        if(washerRepo.findByUserId(id).isEmpty()){
            log.warn("Washer with ID {} not found!", id);
            throw new NotFoundException("Washer with ID " + id + " Not exists");

        }
        log.info("Deleting user with ID: {}", id);
        washerRepo.deleteById(dto.getUserId());
    }

    @Override
    public Optional<WasherDTO> getWasherById(String id) {
        log.info("Fetching user with ID: {}", id);
        Optional<WasherEntity> user = washerRepo.findByUserId(id);
        if(user.isEmpty()){
            log.warn("Washer with ID {} not found",id);
            throw new NotFoundException("Washer with ID " + id + " Not found!!");
        }
        return washerRepo.findByUserId(id)
                .map(user1 -> modelMapper.map(user1, WasherDTO.class));
    }

    public List<WashRequestDTO> getPendingRequestsForWasher(String washerId) {
        return washRequests.values().stream()
                .filter(req -> req.getWasherId().equals(washerId) && "PENDING".equals(req.getStatus()))
                .collect(Collectors.toList());
    }

    public String updateRequestStatus(String bookingId, String newStatus) {
        WashRequestDTO request = washRequests.get(bookingId);
        if (request == null) throw new NotFoundException("Booking not found");
        request.setStatus(newStatus);
        return "Booking status updated to: " + newStatus;
    }

    public void receiveNewRequest(WashRequestDTO dto) {
        dto.setStatus("PENDING");
        washRequests.put(dto.getBookingId(), dto);
    }

    public void savePendingBooking(BookingDTO bookingDTO) {
        WashRequestDTO requestDTO = new WashRequestDTO();
        requestDTO.setBookingId(bookingDTO.getUserBookingId());
        requestDTO.setWasherId(bookingDTO.getWasherId());
        requestDTO.setCustomerName(bookingDTO.getCustomerName());
        requestDTO.setPackageName(bookingDTO.getWashPackage());
        requestDTO.setStatus("PENDING");

        washRequests.put(requestDTO.getBookingId(), requestDTO);
        log.info("Saved new pending booking for washerId: {}", requestDTO.getWasherId());
    }

}
