package com.washerservices.washer_services.dto;

public class CarDetailsDTO {
}
