package com.washerservices.washer_services.util;

import com.customer_service.customerservices.dto.BookingDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@Component
@FeignClient(name = "customer-services", url = "http://localhost:8020")
public interface BookingClientCall {
    @GetMapping("/booking/my-orders/{userId}")
    Map<String, List<BookingDTO>> getBookingsForWasher(@PathVariable("userId") String userId);


    @PutMapping("/bookings/update-status/{id}")
    String updateBookingStatus(@PathVariable("id") String id, @RequestParam("status") String status);

}
