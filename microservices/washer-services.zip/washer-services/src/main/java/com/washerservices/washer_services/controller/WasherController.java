package com.washerservices.washer_services.controller;
import com.customer_service.customerservices.dto.BookingDTO;
import com.washerservices.washer_services.dto.UpdateProfileDTO;
import com.washerservices.washer_services.dto.WashRequestDTO;
import com.washerservices.washer_services.dto.WasherDTO;
import com.washerservices.washer_services.exceptionhandling.NotFoundException;
import com.washerservices.washer_services.services.washer.WasherServicesImp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/request/washer")
public class WasherController {
    @Autowired
    private WasherServicesImp washerServices;

    private static final Logger log = LoggerFactory.getLogger(WasherController.class);


    //Random
    @GetMapping("/rand")
    public String hello(){
        return "Hello";
    }

    //Add user
    @PostMapping("/post")
    public ResponseEntity<WasherDTO> addUser(@RequestParam String email, @RequestBody Map<String,String> requestBody){
        log.info("Received request to save user for email: {}", email);
        String profileImage = requestBody.get("profileImage");
        WasherDTO savedUser = washerServices.addWasher(email, profileImage);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    //Get all users
    @GetMapping("/get")
    public ResponseEntity<List<WasherDTO>> getAllUsers(){
        log.info("Fetching all users records.");
        return ResponseEntity.ok(washerServices.getAllWasher());
    }

    //Get user by id
    @GetMapping("/getBy/{id}")
    public ResponseEntity<WasherDTO> getUserById(@PathVariable String id){
        log.info("Fetching the user details with id {}", id);
        WasherDTO userDTO = washerServices.getWasherById(id).orElseThrow(
                () -> new NotFoundException("User with ID "+ id + " Not found!!")
        );

        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }

    @DeleteMapping("/deleteBy/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable String id) {
        log.info("Deleting the user with id {}", id);
        washerServices.deleteWasher(id);
        return new ResponseEntity<>("User successfully deleted!", HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<UpdateProfileDTO> updateCustomer(@PathVariable String id, @RequestBody UpdateProfileDTO userDTO){
        return ResponseEntity.ok(washerServices.updateWasher(id,userDTO));
    }

    @GetMapping("/my-orders/{washerId}")
    public ResponseEntity<Map<String, List<BookingDTO>>> getWasherOrders(@PathVariable String washerId) {
        log.info("Fetching bookings for washerId: {}", washerId);
        return ResponseEntity.ok(washerServices.getWasherBookings(washerId));
    }

    // Endpoint to simulate a new wash request received
    @PostMapping("/wash-request/receive")
    public ResponseEntity<String> receiveWashRequest(@RequestBody WashRequestDTO dto) {
        washerServices.receiveNewRequest(dto);
        return ResponseEntity.ok("Wash request received!");
    }

    // Get all pending requests for a washer
    @GetMapping("/wash-request/pending/{washerId}")
    public ResponseEntity<List<WashRequestDTO>> getPendingRequests(@PathVariable String washerId) {
        return ResponseEntity.ok(washerServices.getPendingRequestsForWasher(washerId));
    }

    // Accept or Decline a wash request
    @PutMapping("/wash-request/update-status")
    public ResponseEntity<String> updateRequestStatus(@RequestParam String bookingId,
                                                      @RequestParam String status) {
        return ResponseEntity.ok(washerServices.updateRequestStatus(bookingId, status));
    }

    @PostMapping("/wash-request/new")
    public ResponseEntity<String> receiveBooking(@RequestBody BookingDTO bookingDTO) {
        washerServices.savePendingBooking(bookingDTO); // You implement this logic
        return ResponseEntity.ok("Received");
    }


}
