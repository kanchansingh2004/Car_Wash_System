package com.washerservices.washer_services.services.review;

import com.washerservices.washer_services.dto.ReviewDTO;
import com.washerservices.washer_services.entity.ReviewEntity;
import com.washerservices.washer_services.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImp implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public ReviewDTO addReview(ReviewDTO dto) {
        ReviewEntity review = new ReviewEntity();
        review.setWasherId(dto.getWasherId());
        review.setComment(dto.getComment());
        review.setRating(dto.getRating());
        review.setCreatedAt(LocalDateTime.now());
        reviewRepository.save(review);
        return dto;
    }

    @Override
    public List<ReviewDTO> getReviewsForWasher(String washerId) {
        return reviewRepository.findByWasherId(washerId)
                .stream()
                .map(r -> new ReviewDTO(r.getWasherId(), r.getComment(), r.getRating()))
                .collect(Collectors.toList());
    }
}
