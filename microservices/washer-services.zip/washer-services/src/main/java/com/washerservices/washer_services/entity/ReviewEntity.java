package com.washerservices.washer_services.entity;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class ReviewEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String washerId; // Reference to Washer
    private String comment;
    private int rating;

    private LocalDateTime createdAt;
}
