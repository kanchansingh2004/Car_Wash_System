package com.washerservices.washer_services;

import com.washerservices.washer_services.dto.WasherReviewDTO;
import com.washerservices.washer_services.entity.WasherReviewEntity;
import com.washerservices.washer_services.repository.WasherReviewRepository;
import com.washerservices.washer_services.services.review.WasherReviewServiceImp;
import com.washerservices.washer_services.util.BookingClientCall;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Map;
import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WasherReviewServiceTest {

    @Mock
    private WasherReviewRepository reviewRepository;

    @Mock
    private BookingClientCall bookingClientCall;

    @InjectMocks
    private WasherReviewServiceImp washerReviewService;

    private WasherReviewDTO reviewDTO;
    private WasherReviewEntity reviewEntity;

    @BeforeEach
    void setUp() {
        reviewDTO = new WasherReviewDTO("washer1", "customer1", "Great service!", 5);
        reviewEntity = new WasherReviewEntity();
        reviewEntity.setWasherId("washer1");
        reviewEntity.setCustomerId("customer1");
        reviewEntity.setComment("Great service!");
        reviewEntity.setRating(5);
        reviewEntity.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testAddReview() {
        when(reviewRepository.save(any(WasherReviewEntity.class))).thenReturn(reviewEntity);

        WasherReviewDTO savedReview = washerReviewService.addReview(reviewDTO);

        assertNotNull(savedReview);
        assertEquals(reviewDTO.getWasherId(), savedReview.getWasherId());
        assertEquals(reviewDTO.getCustomerId(), savedReview.getCustomerId());
        assertEquals(reviewDTO.getComment(), savedReview.getComment());
        assertEquals(reviewDTO.getRating(), savedReview.getRating());

        verify(reviewRepository, times(1)).save(any(WasherReviewEntity.class));
    }

    @Test
    void testGetReviewsForWasher() {
        when(reviewRepository.findByWasherId("washer1")).thenReturn(Arrays.asList(reviewEntity));

        List<WasherReviewDTO> reviews = washerReviewService.getReviewsForWasher("washer1");

        assertNotNull(reviews);
        assertEquals(1, reviews.size());
        assertEquals("washer1", reviews.get(0).getWasherId());

        verify(reviewRepository, times(1)).findByWasherId("washer1");
    }

    @Test
    void testPostReview() {
        Map<String, String> response = washerReviewService.postReview(reviewDTO);

        assertNotNull(response);
        assertEquals("Review Posted to customer successfully", response.get("Message"));

        verify(bookingClientCall, times(1)).postReviewToCustomerService(reviewDTO);
    }
}