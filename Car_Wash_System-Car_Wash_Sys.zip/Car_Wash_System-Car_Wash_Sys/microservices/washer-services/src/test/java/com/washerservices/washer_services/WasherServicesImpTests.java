package com.washerservices.washer_services;

import com.washerservices.washer_services.dto.*;
import com.washerservices.washer_services.entity.*;
import com.washerservices.washer_services.exceptionhandling.AlreadyPresentException;
import com.washerservices.washer_services.exceptionhandling.NotFoundException;
import com.washerservices.washer_services.repository.*;
import com.washerservices.washer_services.services.washer.WasherServicesImp;
import com.washerservices.washer_services.util.AuthClientCall;
import com.washerservices.washer_services.util.BookingClientCall;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WasherServicesImpTest {

	@Mock
	private WasherRepository washerRepo;
	@Mock
	private AuthClientCall client;
	@Mock
	private ModelMapper modelMapper;
	@Mock
	private BookingClientCall bookingClientCall;
	@Mock
	private PendingRequestRepository pendingRequestRepo;
	@Mock
	private WashRequestRepository washRequestRepo;

	@InjectMocks
	private WasherServicesImp washerServicesImp;

	private WasherDTO washerDTO;
	private WasherEntity washerEntity;
	private WashRequestEntity washRequestEntity;
	private PendingWashRequestEntity pendingWashRequestEntity;
	private BookingDTO bookingDTO;

	@BeforeEach
	void setUp() {
		washerDTO = new WasherDTO("user1", "John", "Doe", "john@example.com", "1234567890", "Address", "profile.jpg", "ROLE_WASHER");
		washerEntity = new WasherEntity();
		washerEntity.setUserId("user1");
		washerEntity.setEmail("john@example.com");

		washRequestEntity = new WashRequestEntity();
		washRequestEntity.setWasherId("user1");
		washRequestEntity.setBookingStatus("Pending");

		pendingWashRequestEntity = new PendingWashRequestEntity();
		pendingWashRequestEntity.setWasherId("user1");
		pendingWashRequestEntity.setBookingStatus("Pending");

		bookingDTO = new BookingDTO();
		bookingDTO.setWasherId("user1");
		bookingDTO.setBookingStatus("Pending");
	}

	@Test
	void testGetAllWashers() {
		when(washerRepo.findAll()).thenReturn(List.of(washerEntity));
		when(modelMapper.map(any(WasherEntity.class), eq(WasherDTO.class))).thenReturn(washerDTO);

		List<WasherDTO> result = washerServicesImp.getAllWasher();

		assertNotNull(result);
		assertEquals(1, result.size());
//		assertEquals("user1", result.get(0).getUserId());
		//verify(washerRepo, times(1)).findAll();
	}

	@Test
	void testAddWasher_Success() throws AlreadyPresentException, NotFoundException {
		when(client.getWasherProfile("john@example.com")).thenReturn(washerDTO);
		when(washerRepo.findByEmail("john@example.com")).thenReturn(Optional.empty());
		when(modelMapper.map(any(WasherDTO.class), eq(WasherEntity.class))).thenReturn(washerEntity);
		when(washerRepo.save(any(WasherEntity.class))).thenReturn(washerEntity);

		String result = washerServicesImp.addWasher(washerDTO);

		assertNotNull(result);
		assertEquals("SUCCESS", result);
		verify(washerRepo, times(1)).save(any(WasherEntity.class));
	}

	@Test
	void testGetWasherBookings_Success() {
		when(washRequestRepo.findAllByWasherId("user1")).thenReturn(List.of(washRequestEntity));
		when(pendingRequestRepo.findAllByWasherId("user1")).thenReturn(List.of(pendingWashRequestEntity));
		when(modelMapper.map(any(WashRequestEntity.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

		Map<String, List<BookingDTO>> result = washerServicesImp.getWasherBookings("user1");

		assertNotNull(result);
		assertFalse(result.get("currentOrders").isEmpty());
		verify(washRequestRepo, times(1)).findAllByWasherId("user1");
	}

	@Test
	void testUpdateRequestStatus_Success() {
		when(pendingRequestRepo.findByUserBookingId("booking1")).thenReturn(pendingWashRequestEntity);
		when(modelMapper.map(any(PendingWashRequestEntity.class), eq(WashRequestEntity.class))).thenReturn(washRequestEntity);
		when(bookingClientCall.updateBookingStatus("booking1", "Confirmed")).thenReturn("Update Successful");

		String result = washerServicesImp.updateRequestStatus("booking1", "Confirmed");

		assertTrue(result.contains("Update Successful"));
		verify(washRequestRepo, times(1)).save(any(WashRequestEntity.class));
		verify(pendingRequestRepo, times(1)).delete(any(PendingWashRequestEntity.class));
	}

	@Test
	void testDeleteWasher_Success() {
		when(washerRepo.findByUserId("user1")).thenReturn(Optional.of(washerEntity));

		washerServicesImp.deleteWasher("user1");

		verify(washerRepo, times(1)).deleteByUserId("user1");
	}

	@Test
	void testDeleteWasher_NotFound() {
		when(washerRepo.findByUserId("user1")).thenReturn(Optional.empty());

		assertThrows(NotFoundException.class, () -> washerServicesImp.deleteWasher("user1"));
		verify(washerRepo, never()).deleteByUserId(anyString());
	}
}