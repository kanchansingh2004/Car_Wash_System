package com.washerservices.washer_services.repository;

import com.washerservices.washer_services.entity.WashRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WashRequestRepository extends JpaRepository<WashRequestEntity,Long> {
    List<WashRequestEntity> findAllByWasherId(String washerId);

    WashRequestEntity findByUserBookingId(String bookingId);
}
