package com.washerservices.washer_services.controller;

import com.washerservices.washer_services.dto.BookingDTO;
import com.washerservices.washer_services.dto.UpdateProfileDTO;
import com.washerservices.washer_services.dto.WashRequestDTO;
import com.washerservices.washer_services.dto.WasherDTO;
import com.washerservices.washer_services.exceptionhandling.NotFoundException;
import com.washerservices.washer_services.services.washer.WasherServicesImp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/request/washer")
public class WasherController {

    @Autowired
    private WasherServicesImp washerServices;

    private static final Logger log = LoggerFactory.getLogger(WasherController.class);

    // Health check
    @GetMapping("/rand")
    public String hello() {
        return "Hello";
    }

    // Add a new washer
    @PostMapping("/post")
    public String addUser(@RequestBody WasherDTO washerDTO) {
        return washerServices.addWasher(washerDTO);
    }

    // Get all washers
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @GetMapping("/get")
    public ResponseEntity<List<WasherDTO>> getAllUsers() {
        return ResponseEntity.ok(washerServices.getAllWasher());
    }

    // Get washer by ID
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @GetMapping("/getBy/{id}")
    public ResponseEntity<WasherDTO> getUserById(@PathVariable String id) {
        WasherDTO userDTO = washerServices.getWasherById(id)
                .orElseThrow(() -> new NotFoundException("User with ID " + id + " Not found!!"));
        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }

    // Delete washer by ID
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @DeleteMapping("/deleteBy/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable String id) {
        washerServices.deleteWasher(id);
        return new ResponseEntity<>("User successfully deleted!", HttpStatus.OK);
    }

    // Update washer profile
    @PreAuthorize("hasAnyRole('WASHER')")
    @PutMapping("/update/{id}")
    public ResponseEntity<UpdateProfileDTO> updateCustomer(@PathVariable String id, @RequestBody UpdateProfileDTO userDTO) {
        UpdateProfileDTO updated = washerServices.updateWasher(id, userDTO);
        return ResponseEntity.ok(updated);
    }

    // Get all bookings for a washer
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @GetMapping("/my-orders/{washerId}")
    public ResponseEntity<Map<String, List<BookingDTO>>> getWasherOrders(@PathVariable String washerId) {
        return ResponseEntity.ok(washerServices.getWasherBookings(washerId));
    }

    // Test: Simulate a new wash request (for testing only)
    @PostMapping("/wash-request/receive")
    public ResponseEntity<String> receiveWashRequest(@RequestBody WashRequestDTO dto) {
        washerServices.receiveNewRequest(dto);
        return ResponseEntity.ok("Wash request received!");
    }

    // Get pending wash requests for washer
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @GetMapping("/wash-request/pending/{washerId}")
    public ResponseEntity<List<WashRequestDTO>> getPendingRequests(@PathVariable String washerId) {
        return ResponseEntity.ok(washerServices.getPendingRequestsForWasher(washerId));
    }

    // Accept or decline a wash request
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @PutMapping("/wash-request/update-status")
    public ResponseEntity<String> updateRequestStatus(@RequestParam String bookingId, @RequestParam String status) {
        return ResponseEntity.ok(washerServices.updateRequestStatus(bookingId, status));
    }

    // Receive a new booking from Booking Service
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @PostMapping("/wash-request/new")
    public ResponseEntity<String> receiveBooking(@RequestBody BookingDTO bookingDTO) {
        washerServices.savePendingBooking(bookingDTO);
        return ResponseEntity.ok("Received");
    }

    // Mark booking as completed
    @PreAuthorize("hasAnyRole('ADMIN','WASHER')")
    @PutMapping("/wash-request/update-completion")
    public ResponseEntity<String> updateRequestStatusToComplete(@RequestParam String bookingId, @RequestParam String status) {
        return ResponseEntity.ok(washerServices.updateRequestToComplete(bookingId, status));
    }
}
