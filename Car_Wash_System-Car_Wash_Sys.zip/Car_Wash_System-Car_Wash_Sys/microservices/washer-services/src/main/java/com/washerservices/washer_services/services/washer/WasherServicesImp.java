package com.washerservices.washer_services.services.washer;

import com.washerservices.washer_services.dto.BookingDTO;
import com.washerservices.washer_services.dto.UpdateProfileDTO;
import com.washerservices.washer_services.dto.WashRequestDTO;
import com.washerservices.washer_services.dto.WasherDTO;
import com.washerservices.washer_services.entity.PendingWashRequestEntity;
import com.washerservices.washer_services.entity.WashRequestEntity;
import com.washerservices.washer_services.entity.WasherEntity;
import com.washerservices.washer_services.exceptionhandling.AlreadyPresentException;
import com.washerservices.washer_services.exceptionhandling.NotFoundException;
import com.washerservices.washer_services.repository.PendingRequestRepository;
import com.washerservices.washer_services.repository.WashRequestRepository;
import com.washerservices.washer_services.repository.WasherRepository;
import com.washerservices.washer_services.util.AuthClientCall;
import com.washerservices.washer_services.util.BookingClientCall;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class WasherServicesImp implements WasherService {
    @Autowired private WasherRepository washerRepo;
    @Autowired private AuthClientCall client;
    @Autowired private ModelMapper modelMapper;
    @Autowired private BookingClientCall bookingClientCall;
    @Autowired private PendingRequestRepository pendingRequestRepo;
    @Autowired private WashRequestRepository washRequestRepo;

    private static final Logger log = LoggerFactory.getLogger(WasherServicesImp.class);

    public Map<String, List<BookingDTO>> getWasherBookings(String washerId) {
        log.info("Fetching all bookings for washerId: {}", washerId);
        List<WashRequestEntity> allConfirmAndCompleteBookings = washRequestRepo.findAllByWasherId(washerId);
        List<PendingWashRequestEntity> allPendingBookings = pendingRequestRepo.findAllByWasherId(washerId);

        if(allPendingBookings.isEmpty() && allConfirmAndCompleteBookings.isEmpty()){
            log.info("No orders found for washer ID: {}", washerId);
            throw new NotFoundException("No orders found for washer ID: " + washerId);
        }
        List<BookingDTO> current = new ArrayList<>();
        List<BookingDTO> past = new ArrayList<>();

        for (WashRequestEntity booking : allConfirmAndCompleteBookings) {
            BookingDTO dto = modelMapper.map(booking, BookingDTO.class);
            if ("Completed".equalsIgnoreCase(booking.getBookingStatus()) ||
                    "Cancelled".equalsIgnoreCase(booking.getBookingStatus())) {

                past.add(dto);
            } else {
                current.add(dto);
            }
        }

        for (PendingWashRequestEntity booking : allPendingBookings) {
            BookingDTO dto = modelMapper.map(booking, BookingDTO.class);
            current.add(dto);
        }

        log.info("Retrieved {} current and {} past orders for washerId {}", current.size(), past.size(), washerId);

        return Map.of(
                "currentOrders", current,
                "pastOrders", past
        );
    }

    @Override
    public List<WasherDTO> getAllWasher() {
        log.info("Fetching all washers from DB");
        List<WasherEntity> users = washerRepo.findAll();
        return users.stream()
                .map(user -> modelMapper.map(user, WasherDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public String addWasher(WasherDTO washerDTO) {
        log.info("Adding washer with email: {}", washerDTO.getEmail());
        washerDTO.setEmail(washerDTO.getEmail());
        washerDTO.setFirstName(washerDTO.getFirstName());
        washerDTO.setLastName(washerDTO.getLastName());
        washerDTO.setAddress(washerDTO.getAddress());
        washerDTO.setPhone(washerDTO.getPhone());
        washerDTO.setRole(washerDTO.getRole());
        washerDTO.setUserId(washerDTO.getUserId());

        TypeMap<WasherDTO, WasherEntity> typeMap = modelMapper.typeMap(WasherDTO.class, WasherEntity.class);
        typeMap.addMappings(mapper -> {
            mapper.skip(WasherEntity::setId);
            mapper.map(WasherDTO::getUserId, WasherEntity::setUserId);
        });

        WasherEntity entity = modelMapper.map(washerDTO, WasherEntity.class);
        washerRepo.save(entity);

        log.info("Washer added successfully: {}", washerDTO.getEmail());
        return "SUCCESS";
    }

    @Override
    public UpdateProfileDTO updateWasher(String id, UpdateProfileDTO userDTO) {
        log.info("Updating washer with ID: {}", id);
        return washerRepo.findByUserId(id).map(entity -> {
            entity.setFirstName(userDTO.getFirstName());
            entity.setLastName(userDTO.getLastName());
            entity.setPhone(userDTO.getPhone());
            entity.setAddress(userDTO.getAddress());
            entity.setEmail(userDTO.getEmail());
            entity.setProfileImage(userDTO.getProfileImage());
            WasherEntity updatedEntity = washerRepo.save(entity);
            log.info("Washer updated for ID: {}", id);
            return modelMapper.map(updatedEntity, UpdateProfileDTO.class);
        }).orElse(null);
    }

    @Override
    public void deleteWasher(String id){
        log.info("Attempting to delete washer with ID: {}", id);
        if(washerRepo.findByUserId(id).isEmpty()){
            log.warn("Washer with ID {} not found!", id);
            throw new NotFoundException("Washer with ID " + id + " Not exists");
        }
        WasherEntity dto = washerRepo.findByUserId(id).get();
        washerRepo.deleteByUserId(dto.getUserId());
        log.info("Washer deleted with ID: {}", id);
    }

    @Override
    public Optional<WasherDTO> getWasherById(String id) {
        log.info("Fetching washer by ID: {}", id);
        Optional<WasherEntity> user = washerRepo.findByUserId(id);
        if(user.isEmpty()){
            log.warn("Washer not found with ID: {}", id);
            throw new NotFoundException("Washer with ID " + id + " Not found!!");
        }
        return user.map(u -> modelMapper.map(u, WasherDTO.class));
    }

    public List<WashRequestDTO> getPendingRequestsForWasher(String washerId) {
        log.info("Fetching pending requests for washerId: {}", washerId);
        List<PendingWashRequestEntity> list = pendingRequestRepo.findAllByWasherId(washerId);
        return list.stream().map(x -> modelMapper.map(x, WashRequestDTO.class)).toList();
    }

    public String updateRequestStatus(String bookingId, String newStatus) {
        log.info("Updating booking status for bookingId: {} to {}", bookingId, newStatus);
        PendingWashRequestEntity request = pendingRequestRepo.findByUserBookingId(bookingId);
        if (request == null) {
            log.warn("Booking not found with ID: {}", bookingId);
            throw new NotFoundException("Booking not found");
        }

        if(newStatus.equalsIgnoreCase("Cancelled") && request.getBookingStatus().equalsIgnoreCase("Confirmed")) {
            LocalDate date = request.getWashDate();
            LocalTime time = request.getWashTime();
            LocalDateTime scheduledDateTime = LocalDateTime.of(date, time);

            LocalDateTime now = LocalDateTime.now();
            if (now.isAfter(scheduledDateTime.minusHours(2))) {
                throw new RuntimeException("Cannot cancel within 2 hours of the scheduled wash time.");
            }
        }


        request.setBookingStatus(newStatus);
        washRequestRepo.save(modelMapper.map(request,WashRequestEntity.class));
        String response = bookingClientCall.updateBookingStatus(bookingId, newStatus);
        pendingRequestRepo.delete(request);
        log.info("Booking status updated and request deleted for bookingId: {}", bookingId);
        return "Booking status updated locally and sent to Customer Service. Response: " + response;
    }

    public String updateRequestToComplete(String bookingId, String newStatus){
        log.info("Updating booking status to complete for bookingId: {} to {}", bookingId, newStatus);
        WashRequestEntity request = washRequestRepo.findByUserBookingId(bookingId);

        if (request.getBookingStatus().equalsIgnoreCase("Pending") || request.getBookingStatus().equalsIgnoreCase("Cancelled")) {
            log.warn("Booking status for ID {} is either Pending or Completed", bookingId);
            throw new NotFoundException("Booking status can not be updated!!!!");
        }

        request.setBookingStatus(newStatus);
        washRequestRepo.save(request);
        String response = bookingClientCall.updateBookingStatus(bookingId, newStatus);
        log.info("Booking status updated for bookingId: {}", bookingId);
        return "Booking status updated locally and sent to Customer Service. Response: " + response;
    }


    public void receiveNewRequest(WashRequestDTO dto) {
        dto.setBookingStatus("PENDING");
        pendingRequestRepo.save(modelMapper.map(dto, PendingWashRequestEntity.class));
        log.info("Received new request for washerId: {}", dto.getWasherId());
    }

    public void savePendingBooking(BookingDTO bookingDTO) {
        PendingWashRequestEntity bookingEntity = new PendingWashRequestEntity();
        bookingEntity.setUserBookingId(bookingDTO.getUserBookingId());
        bookingEntity.setCarId(bookingDTO.getCarId());
        bookingEntity.setUserId(bookingDTO.getUserId());
        bookingEntity.setWasherId(bookingDTO.getWasherId());
        bookingEntity.setCustomerName(bookingDTO.getCustomerName());
        bookingEntity.setCustomerEmail(bookingDTO.getCustomerEmail());
        bookingEntity.setWashAddress(bookingDTO.getWashAddress());
        bookingEntity.setAddOns(bookingDTO.getAddOns());
        bookingEntity.setNotes(bookingDTO.getNotes());
        bookingEntity.setWashPackage(bookingDTO.getWashPackage());
        bookingEntity.setWashDate(bookingDTO.getWashDate());
        bookingEntity.setWashTime(bookingDTO.getWashTime());
        bookingEntity.setBookingTime(bookingDTO.getBookingTime());
        bookingEntity.setBookingStatus(bookingDTO.getBookingStatus());

        pendingRequestRepo.save(bookingEntity);
        log.info("Saved new pending booking for washerId: {}", bookingEntity.getWasherId());
    }
}