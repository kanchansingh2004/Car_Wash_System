package com.washerservices.washer_services.configuration;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

@Component
public class JWTUtil {

    private static final Logger logger = LoggerFactory.getLogger(JWTUtil.class);
    private static final String SECRET = "your_strong_secret_key_here_256bit+";
    public static final long ACCESS_TOKEN_EXPIRE_TIME = 60 * 60 * 1000; // 1 hour
    private static final long REFRESH_TOKEN_EXPIRE_TIME = 10 * 60 * 60 * 1000; // 10 hours

    private Key getSigningKey() {
        logger.debug("Generating signing key for JWT");
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    public String generateAccessToken(String email, String role) {
        logger.info("Generating access token for user: {}, role: {}", email, role);
        return Jwts.builder()
                .setSubject(email)
                .claim("type", "access")
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + ACCESS_TOKEN_EXPIRE_TIME))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateRefreshToken(String email) {
        logger.info("Generating refresh token for user: {}", email);
        return Jwts.builder()
                .setSubject(email)
                .claim("type", "refresh")
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + REFRESH_TOKEN_EXPIRE_TIME))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token);
            logger.debug("Token validation successful");
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            logger.warn("Token validation failed: {}", e.getMessage());
            return false;
        }
    }

    public String getTokenType(String token) {
        String type = extractClaim(token, claims -> claims.get("type", String.class));
        logger.debug("Extracted token type: {}", type);
        return type;
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
            logger.debug("Claims successfully extracted");
            return claimsResolver.apply(claims);
        } catch (JwtException e) {
            logger.error("Failed to extract claims: {}", e.getMessage());
            throw e;
        }
    }
}
