package com.washerservices.washer_services.repository;

import com.washerservices.washer_services.entity.PendingWashRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PendingRequestRepository extends JpaRepository<PendingWashRequestEntity, Long> {
    PendingWashRequestEntity findByUserBookingId(String userBookingId);
    List<PendingWashRequestEntity> findAllByWasherId(String washerId);
}
