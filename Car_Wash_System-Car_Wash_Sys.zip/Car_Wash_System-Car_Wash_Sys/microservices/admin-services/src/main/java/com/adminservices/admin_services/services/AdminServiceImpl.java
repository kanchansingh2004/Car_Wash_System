package com.adminservices.admin_services.services;

import com.adminservices.admin_services.dto.AdminDTO;
import com.adminservices.admin_services.entity.AdminEntity;
import com.adminservices.admin_services.repository.AdminRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    private static final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

    @Autowired
    private AdminRepo adminRepo;

    @Override
    public String createAdmin(AdminDTO dto) {
        logger.info("Creating admin with email: {}", dto.getEmail());
        AdminEntity entity = toEntity(dto);
        AdminEntity saved = adminRepo.save(entity);
        logger.debug("Admin created with ID: {}", saved.getUserId());
        return "SUCCESS";
    }

    @Override
    public AdminDTO getAdminByUserId(String userId) {
        logger.info("Fetching admin by userId: {}", userId);
        return adminRepo.findById(userId)
                .map(admin -> {
                    logger.debug("Admin found: {}", admin.getEmail());
                    return toDTO(admin);
                })
                .orElseGet(() -> {
                    logger.warn("No admin found with userId: {}", userId);
                    return null;
                });
    }

    @Override
    public List<AdminDTO> getAllAdmins() {
        logger.info("Retrieving all admins");
        List<AdminDTO> list = adminRepo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        logger.debug("Total admins retrieved: {}", list.size());
        return list;
    }

    @Override
    public AdminDTO updateAdmin(String userId, AdminDTO dto) {
        logger.info("Updating admin with userId: {}", userId);
        AdminEntity entity = adminRepo.findById(userId)
                .orElseThrow(() -> {
                    logger.error("Admin not found with userId: {}", userId);
                    return new RuntimeException("Admin not found with userId: " + userId);
                });

        entity.setFirstName(dto.getFirstName());
        entity.setLastName(dto.getLastName());
        entity.setEmail(dto.getEmail());
        entity.setPhone(dto.getPhone());
        entity.setAddress(dto.getAddress());
        entity.setRole(dto.getRole());
        entity.setProfileImage(dto.getProfileImage());

        AdminEntity updated = adminRepo.save(entity);
        logger.debug("Admin with userId {} updated successfully", userId);
        return toDTO(updated);
    }

    @Override
    public void deleteAdmin(String userId) {
        logger.info("Deleting admin with userId: {}", userId);
        if (!adminRepo.existsById(userId)) {
            logger.error("Delete failed. Admin not found: {}", userId);
            throw new RuntimeException("Admin not found with userId: " + userId);
        }
        adminRepo.deleteById(userId);
        logger.info("Admin deleted successfully: {}", userId);
    }

    // 🔁 Mapping helpers
    private AdminDTO toDTO(AdminEntity entity) {
        AdminDTO dto = new AdminDTO();
        dto.setUserId(entity.getUserId());
        dto.setEmail(entity.getEmail());
        dto.setFirstName(entity.getFirstName());
        dto.setLastName(entity.getLastName());
        dto.setPhone(entity.getPhone());
        dto.setAddress(entity.getAddress());
        dto.setRole(entity.getRole());
        dto.setProfileImage(entity.getProfileImage());
        return dto;
    }

    private AdminEntity toEntity(AdminDTO dto) {
        AdminEntity entity = new AdminEntity();
        entity.setUserId(dto.getUserId());
        entity.setEmail(dto.getEmail());
        entity.setFirstName(dto.getFirstName());
        entity.setLastName(dto.getLastName());
        entity.setPhone(dto.getPhone());
        entity.setAddress(dto.getAddress());
        entity.setRole(dto.getRole());
        entity.setProfileImage(dto.getProfileImage());
        return entity;
    }
}