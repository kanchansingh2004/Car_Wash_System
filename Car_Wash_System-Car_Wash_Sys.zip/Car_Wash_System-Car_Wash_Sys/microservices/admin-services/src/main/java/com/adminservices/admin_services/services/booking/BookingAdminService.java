package com.adminservices.admin_services.services.booking;

import com.adminservices.admin_services.dto.BookingDTO;
import com.adminservices.admin_services.util.BookingServiceClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class BookingAdminService {

    private static final Logger logger = LoggerFactory.getLogger(BookingAdminService.class);

    @Autowired
    private BookingServiceClient bookingClient;

    public List<BookingDTO> getAllBookings() {
        logger.info("Admin requested all bookings");
        return bookingClient.getAllBookings();
    }

    public BookingDTO getBookingById(String bookingId) {
        logger.info("Admin fetching booking with ID: {}", bookingId);
        return bookingClient.getBookingById(bookingId);
    }

    public Map<String, List<BookingDTO>> getBookingsByUser(String userId) {
        logger.info("Admin fetching bookings for user ID: {}", userId);
        return bookingClient.getBookingsByUser(userId);
    }
}
