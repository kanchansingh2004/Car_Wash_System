package com.adminservices.admin_services.repository;

import com.adminservices.admin_services.entity.AdminEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminRepo extends JpaRepository<AdminEntity, String> {

    // Find by unique userId
    Optional<AdminEntity> findByUserId(String userId);

    // Find by unique email
    Optional<AdminEntity> findByEmail(String email);

    // Check existence by email
    boolean existsByEmail(String email);

    // Check existence by userId
    boolean existsByUserId(String userId);
}