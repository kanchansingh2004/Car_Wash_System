package com.adminservices.admin_services.controller;

import com.adminservices.admin_services.dto.AdminDTO;
import com.adminservices.admin_services.services.AdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/request/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    // Create
    @PostMapping("/post")
    public String addUser(@RequestBody AdminDTO adminDTO) {
        logger.info("Creating new admin with email: {}", adminDTO.getEmail());
        String response = adminService.createAdmin(adminDTO);
        logger.debug("Admin created successfully with userId: {}", adminDTO.getUserId());
        return response;
    }

    // Read All
    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping
    public List<AdminDTO> getAllAdmins() {
        logger.info("Fetching all admin records");
        List<AdminDTO> admins = adminService.getAllAdmins();
        logger.debug("Total admins fetched: {}", admins.size());
        return admins;
    }

    // Read by ID
    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/{id}")
    public AdminDTO getAdminById(@PathVariable String id) {
        logger.info("Fetching admin by ID: {}", id);
        return adminService.getAdminByUserId(id);
    }

    // Update
    @PreAuthorize("hasAnyRole('ADMIN')")
    @PutMapping("/{id}")
    public AdminDTO updateAdmin(@PathVariable String id, @RequestBody AdminDTO adminDTO) {
        logger.info("Updating admin with ID: {}", id);
        return adminService.updateAdmin(id, adminDTO);
    }

    // Delete
    @PreAuthorize("hasAnyRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteAdmin(@PathVariable String id) {
        logger.warn("Attempting to delete admin with ID: {}", id);
        adminService.deleteAdmin(id);
        logger.info("Admin with ID {} deleted successfully", id);
        return "Admin with ID " + id + " deleted successfully.";
    }
}