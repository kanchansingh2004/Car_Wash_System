package com.adminservices.admin_services.services;

import com.adminservices.admin_services.dto.AdminDTO;

import java.util.List;

public interface AdminService {
    String createAdmin(AdminDTO adminDTO);
    AdminDTO getAdminByUserId(String userId);
    List<AdminDTO> getAllAdmins();
    AdminDTO updateAdmin(String userId, AdminDTO adminDTO);
    void deleteAdmin(String userId);
}