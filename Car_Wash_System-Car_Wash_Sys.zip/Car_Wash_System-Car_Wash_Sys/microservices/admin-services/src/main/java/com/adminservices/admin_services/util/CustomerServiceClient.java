package com.adminservices.admin_services.util;

import com.adminservices.admin_services.configuration.FeignClientInterceptorConfig;
import com.adminservices.admin_services.dto.CarDetailsDTO;
import com.adminservices.admin_services.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(name = "customer-services", contextId = "customerClient", url = "http://localhost:8020/request/customer", configuration = FeignClientInterceptorConfig.class)
public interface CustomerServiceClient {
    //---------Customer--------------
    @GetMapping("/get")
    List<CustomerDTO> getAllCustomers();

    @GetMapping("/getBy/{id}")
    CustomerDTO getCustomerById(@PathVariable String id);

    @DeleteMapping("/deleteBy/{id}")
    String deleteCustomer(@PathVariable String id);

    //-----------Car-------------------
    //Get All Cars
    @GetMapping("/car/getAllCars")
    List<CarDetailsDTO> getAllCars();

    // Get Car by Car Number
    @GetMapping("/car/getCar/{carNumber}")
    CarDetailsDTO getCarByNumber(@PathVariable String carNumber);

    @DeleteMapping("/car/deleteCar/{carNumber}")
    Map<String, String> deleteCar(@PathVariable String carNumber);

    // Get All Cars
    @GetMapping("/car/getAllCarsByUser")
    List<CarDetailsDTO> getAllCarsByUser(@RequestParam String userId);
}
