package com.adminservices.admin_services.util;

import com.adminservices.admin_services.configuration.FeignClientInterceptorConfig;
import com.adminservices.admin_services.dto.CustomerReviewDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(
        name = "customer-services",
        contextId = "reviewClient",
        url = "http://localhost:8020/api/customer/review",
        configuration = FeignClientInterceptorConfig.class
)
public interface ReviewServiceClient {

    @GetMapping("/getReview/{customerId}")
    List<CustomerReviewDTO> getReviewsByCustomer(@PathVariable String customerId);
}
