package com.adminservices.admin_services.services.review;

import com.adminservices.admin_services.dto.CustomerReviewDTO;
import com.adminservices.admin_services.util.ReviewServiceClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminReviewService {

    private static final Logger logger = LoggerFactory.getLogger(AdminReviewService.class);
    private final ReviewServiceClient reviewClient;

    public AdminReviewService(ReviewServiceClient reviewClient) {
        this.reviewClient = reviewClient;
    }

    public List<CustomerReviewDTO> getReviewsByCustomer(String customerId) {
        logger.info("Admin requested reviews for customer ID: {}", customerId);
        return reviewClient.getReviewsByCustomer(customerId);
    }
}
