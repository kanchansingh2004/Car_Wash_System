package com.adminservices.admin_services.controller;

import com.adminservices.admin_services.dto.CustomerReviewDTO;
import com.adminservices.admin_services.services.review.AdminReviewService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/reviews")
public class AdminReviewController {

    private static final Logger logger = LoggerFactory.getLogger(AdminReviewController.class);
    private final AdminReviewService reviewService;

    public AdminReviewController(AdminReviewService reviewService) {
        this.reviewService = reviewService;
    }
    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<CustomerReviewDTO>> getReviewsByCustomer(@PathVariable String customerId) {
        logger.info("GET /admin/reviews/customer/{}", customerId);
        return ResponseEntity.ok(reviewService.getReviewsByCustomer(customerId));
    }
}
