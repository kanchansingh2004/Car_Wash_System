package com.adminservices.admin_services.util;

import com.adminservices.admin_services.configuration.FeignClientInterceptorConfig;
import com.adminservices.admin_services.dto.BookingDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Map;

@FeignClient(name = "customer-services", contextId = "bookingClient", url = "http://localhost:8020/request/customer/booking", configuration = FeignClientInterceptorConfig.class)
public interface BookingServiceClient {

    @GetMapping("/all")
    List<BookingDTO> getAllBookings();

    @GetMapping("/{bookingId}")
    BookingDTO getBookingById(@PathVariable String bookingId);

    @GetMapping("/my-orders/{userId}")
    Map<String, List<BookingDTO>> getBookingsByUser(@PathVariable String userId);
}

