package com.adminservices.admin_services.controller;


import com.adminservices.admin_services.dto.BookingDTO;
import com.adminservices.admin_services.services.booking.BookingAdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/bookings")
public class BookingAdminController {

    private static final Logger logger = LoggerFactory.getLogger(BookingAdminController.class);

    private BookingAdminService adminBookingService;

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<BookingDTO>> getAllBookings() {
        logger.info("GET /admin/bookings");
        return ResponseEntity.ok(adminBookingService.getAllBookings());
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable String bookingId) {
        logger.info("GET /admin/bookings/{}", bookingId);
        return ResponseEntity.ok(adminBookingService.getBookingById(bookingId));
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/user/{userId}")
    public ResponseEntity<Map<String, List<BookingDTO>>> getBookingsByUser(@PathVariable String userId) {
        logger.info("GET /admin/bookings/user/{}", userId);
        return ResponseEntity.ok(adminBookingService.getBookingsByUser(userId));
    }
}
