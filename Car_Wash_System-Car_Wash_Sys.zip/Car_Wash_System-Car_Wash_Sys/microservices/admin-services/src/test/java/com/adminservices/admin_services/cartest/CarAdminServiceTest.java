package com.adminservices.admin_services.cartest;

import com.adminservices.admin_services.services.car.CarAdminService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

import static org.springframework.test.util.AssertionErrors.assertTrue;

@SpringBootTest
public class CarAdminServiceTest {

    @Autowired
    CarAdminService service;
    @Test
    void getAllCarsTest(){
        List<Map<String, Object>> list = service.getAllCars();
        assert(list.isEmpty());
    }
}
