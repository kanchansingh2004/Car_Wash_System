package com.customer_service.customerservices;

import com.customer_service.customerservices.dto.CustomerReviewDTO;
import com.customer_service.customerservices.entity.CustomerReviewEntity;
import com.customer_service.customerservices.repository.CustomerReviewRepo;
import com.customer_service.customerservices.services.reviews.CustomerReviewServiceImp;
import com.customer_service.customerservices.util.WasherClientCall;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerReviewServiceImpTest {

    @Mock
    private CustomerReviewRepo reviewRepository;

    @Mock
    private WasherClientCall washerClientCall;

    @InjectMocks
    private CustomerReviewServiceImp customerReviewServiceImp;

    private CustomerReviewDTO reviewDTO;
    private CustomerReviewEntity reviewEntity;

    @BeforeEach
    void setUp() {
        reviewDTO = new CustomerReviewDTO("washer1", "customer1", "Great service!", 5);
        reviewEntity = new CustomerReviewEntity();
        reviewEntity.setWasherId("washer1");
        reviewEntity.setCustomerId("customer1");
        reviewEntity.setComment("Great service!");
        reviewEntity.setRating(5);
        reviewEntity.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testAddReview() {
        when(reviewRepository.save(any(CustomerReviewEntity.class))).thenReturn(reviewEntity);

        CustomerReviewDTO savedReview = customerReviewServiceImp.addReview(reviewDTO);

        assertNotNull(savedReview);
        assertEquals(reviewDTO.getWasherId(), savedReview.getWasherId());
        assertEquals(reviewDTO.getCustomerId(), savedReview.getCustomerId());
        assertEquals(reviewDTO.getComment(), savedReview.getComment());
        assertEquals(reviewDTO.getRating(), savedReview.getRating());

        verify(reviewRepository, times(1)).save(any(CustomerReviewEntity.class));
    }

    @Test
    void testGetReviewsForCustomer() {
        when(reviewRepository.findByCustomerId("customer1")).thenReturn(List.of(reviewEntity));

        List<CustomerReviewDTO> reviews = customerReviewServiceImp.getReviewsForCustomer("customer1");

        assertNotNull(reviews);
        assertEquals(1, reviews.size());
        assertEquals("customer1", reviews.get(0).getCustomerId());

        verify(reviewRepository, times(1)).findByCustomerId("customer1");
    }

    @Test
    void testPostReview() {
        Map<String, String> response = customerReviewServiceImp.postReview(reviewDTO);

        assertNotNull(response);
        assertEquals("Review Posted to washer successfully", response.get("Message"));

        verify(washerClientCall, times(1)).postReviewToWasherService(reviewDTO);
    }
}