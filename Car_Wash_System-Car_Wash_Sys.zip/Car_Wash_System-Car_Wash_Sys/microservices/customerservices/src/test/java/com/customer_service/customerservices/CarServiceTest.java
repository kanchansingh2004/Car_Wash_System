package com.customer_service.customerservices;

import com.customer_service.customerservices.dto.CarDetailsDTO;
import com.customer_service.customerservices.entity.CarDetails;
import com.customer_service.customerservices.entity.CustomerEntity;
import com.customer_service.customerservices.exceptionhandling.NotFoundException;
import com.customer_service.customerservices.repository.CarRepo;
import com.customer_service.customerservices.repository.CustomerRepo;
import com.customer_service.customerservices.services.carservice.CarService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CarServiceTest {

    @Mock
    private CarRepo carRepo;

    @Mock
    private CustomerRepo customerRepo;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CarService carService;

    private CarDetailsDTO carDetailsDTO;
    private CarDetails carDetails;

    @BeforeEach
    void setUp() {
        carDetailsDTO = new CarDetailsDTO();
        carDetailsDTO.setCarNumber("XYZ123");
        carDetailsDTO.setCarModel("Tesla Model S");
        carDetailsDTO.setCarImages(String.valueOf(List.of("image1.jpg", "image2.jpg")));

        carDetails = new CarDetails();
        carDetails.setCarNumber("XYZ123");
        carDetails.setCarModel("Tesla Model S");
        carDetails.setCarImages(String.valueOf(List.of("image1.jpg", "image2.jpg")));
        carDetails.setCarId("CARID_" + UUID.randomUUID().toString().substring(0, 8));
        carDetails.setUserId("user123");
    }

    @Test
    void testAddCarDetails_Success() {
        CustomerEntity mockCustomer = new CustomerEntity();

        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.empty());
        when(customerRepo.findByUserId("user123")).thenReturn(Optional.of(mockCustomer));
        when(carRepo.save(any(CarDetails.class))).thenReturn(carDetails);

        var response = carService.addCarDetails(carDetailsDTO, "user123");

        assertEquals("Car register successfully", response.get("Message"));
        verify(carRepo, times(1)).save(any(CarDetails.class));
    }

    @Test
    void testAddCarDetails_AlreadyRegistered() {
        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.of(carDetails));

        var response = carService.addCarDetails(carDetailsDTO, "user123");

        assertEquals("Car is already registered!!", response.get("Message"));
        verify(carRepo, never()).save(any(CarDetails.class));
    }

    @Test
    void testGetAllCars_Success() {
        when(carRepo.findAll()).thenReturn(List.of(carDetails));
        when(modelMapper.map(any(CarDetails.class), eq(CarDetailsDTO.class))).thenReturn(carDetailsDTO);

        List<CarDetailsDTO> result = carService.getAllCars();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("XYZ123", result.get(0).getCarNumber());
    }

    @Test
    void testGetAllCarsByUser_Success() {
        when(customerRepo.findByUserId("user123")).thenReturn(Optional.of(new CustomerEntity()));
        when(carRepo.findAllByUserId("user123")).thenReturn(Optional.of(List.of(carDetails)));
        when(modelMapper.map(any(CarDetails.class), eq(CarDetailsDTO.class))).thenReturn(carDetailsDTO);

        List<CarDetailsDTO> result = carService.getAllCarsByUser("user123");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("XYZ123", result.get(0).getCarNumber());

        verify(customerRepo, times(1)).findByUserId("user123");
        verify(carRepo, times(1)).findAllByUserId("user123");
    }

    @Test
    void testGetAllCarsByUser_NotFound() {
        when(customerRepo.findByUserId("user123")).thenReturn(Optional.empty());

        List<CarDetailsDTO> result = carService.getAllCarsByUser("user123");

        assertNull(result);
    }

    @Test
    void testDetail_Success() {
        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.of(carDetails));
        when(modelMapper.map(any(CarDetails.class), eq(CarDetailsDTO.class))).thenReturn(carDetailsDTO);

        CarDetailsDTO result = carService.detail("XYZ123");

        assertNotNull(result);
        assertEquals("XYZ123", result.getCarNumber());
    }

    @Test
    void testDetail_NotFound() {
        when(carRepo.findByCarNumber("INVALID")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> carService.detail("INVALID"));
    }

    @Test
    void testUpdateDetails_Success() {
        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.of(carDetails));
        when(modelMapper.map(any(CarDetails.class), eq(CarDetailsDTO.class))).thenReturn(carDetailsDTO);

        CarDetailsDTO updatedCar = carService.updateDetails(carDetailsDTO, "XYZ123");

        assertNotNull(updatedCar);
        assertEquals("Tesla Model S", updatedCar.getCarModel());
        verify(carRepo, times(1)).save(any(CarDetails.class));
    }

    @Test
    void testUpdateDetails_NotFound() {
        when(carRepo.findByCarNumber("INVALID")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> carService.updateDetails(carDetailsDTO, "INVALID"));
    }

    @Test
    void testDeleteCar_Success() {
        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.of(carDetails));

        var response = carService.deleteCar("XYZ123");

        assertEquals("Car details deleted successfully!!", response.get("Message"));
        verify(carRepo, times(1)).deleteByCarNumber("XYZ123");
    }

    @Test
    void testDeleteCar_NotFound() {
        when(carRepo.findByCarNumber("INVALID")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> carService.deleteCar("INVALID"));
    }
}