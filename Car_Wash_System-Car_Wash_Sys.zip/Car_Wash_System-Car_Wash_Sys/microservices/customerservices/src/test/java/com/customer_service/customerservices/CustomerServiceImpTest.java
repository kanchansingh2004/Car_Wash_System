package com.customer_service.customerservices;

import com.customer_service.customerservices.dto.CustomerDTO;
import com.customer_service.customerservices.entity.CustomerEntity;
import com.customer_service.customerservices.exceptionhandling.AlreadyPresentException;
import com.customer_service.customerservices.exceptionhandling.NotFoundException;
import com.customer_service.customerservices.repository.CustomerRepo;
import com.customer_service.customerservices.services.customer.CustomerServiceImp;
import com.customer_service.customerservices.util.AuthClientCall;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImpTest {

	@Mock
	private CustomerRepo customerRepo;

	@Mock
	private AuthClientCall client;

	@Mock
	private ModelMapper modelMapper;

	@InjectMocks
	private CustomerServiceImp customerServiceImp;

	private CustomerDTO customerDTO;
	private CustomerEntity customerEntity;

	@BeforeEach
	void setUp() {
		customerDTO = new CustomerDTO();
		customerDTO.setUserId("user123");
		customerDTO.setEmail("john@example.com");
		customerDTO.setFirstName("John");
		customerDTO.setLastName("Doe");
		customerDTO.setProfileImage("profile.jpg");

		customerEntity = new CustomerEntity();
		customerEntity.setUserId("user123");
		customerEntity.setEmail("john@example.com");
		customerEntity.setFirstName("John");
		customerEntity.setLastName("Doe");
		customerEntity.setProfileImage("profile.jpg");
	}

	@Test
	void testGetAllCustomer_Success() {
		when(customerRepo.findAll()).thenReturn(List.of(customerEntity));
		when(modelMapper.map(any(CustomerEntity.class), eq(CustomerDTO.class))).thenReturn(customerDTO);

		List<CustomerDTO> result = customerServiceImp.getAllCustomer();

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("user123", result.get(0).getUserId());
		verify(customerRepo, times(1)).findAll();
	}

	@Test
	void testAddCustomer_Success() {
		when(customerRepo.findByEmail("john@example.com")).thenReturn(Optional.empty());
		when(modelMapper.map(any(CustomerDTO.class), eq(CustomerEntity.class))).thenReturn(customerEntity);
		when(customerRepo.save(any(CustomerEntity.class))).thenReturn(customerEntity);

		String result = customerServiceImp.addCustomer(customerDTO);
		assertEquals("SUCCESS",result );
		verify(customerRepo, times(1)).save(any(CustomerEntity.class));
	}

	@Test
	void testAddCustomer_AlreadyPresent() {
		when(client.getProfile("john@example.com")).thenReturn(customerDTO);
		when(customerRepo.findByEmail("john@example.com")).thenReturn(Optional.of(customerEntity));

		assertThrows(AlreadyPresentException.class, () -> customerServiceImp.addCustomer(customerDTO));
	}

	@Test
	void testUpdateCustomer_Success() {
		when(customerRepo.findByUserId("user123")).thenReturn(Optional.of(customerEntity));
		when(modelMapper.map(any(CustomerEntity.class), eq(CustomerDTO.class))).thenReturn(customerDTO);

		CustomerDTO result = customerServiceImp.updateCustomer("user123", customerDTO);

		assertNotNull(result);
		assertEquals("John", result.getFirstName());
		verify(customerRepo, times(1)).save(any(CustomerEntity.class));
	}

	@Test
	void testDeleteCustomer_Success() {
		when(customerRepo.findByUserId("user123")).thenReturn(Optional.of(customerEntity));

		customerServiceImp.deleteCustomer("user123");

		verify(customerRepo, times(1)).deleteById(customerEntity.getId());
	}

	@Test
	void testDeleteCustomer_NotFound() {
		when(customerRepo.findByUserId("invalid_user")).thenReturn(Optional.empty());

		assertThrows(NotFoundException.class, () -> customerServiceImp.deleteCustomer("invalid_user"));
	}

	@Test
	void testGetCustomerById_Success() {
		when(customerRepo.findByUserId("user123")).thenReturn(Optional.of(customerEntity));
		when(modelMapper.map(any(CustomerEntity.class), eq(CustomerDTO.class))).thenReturn(customerDTO);

		Optional<CustomerDTO> result = customerServiceImp.getCustomerById("user123");

		assertTrue(result.isPresent());
		assertEquals("John", result.get().getFirstName());
	}

	@Test
	void testGetCustomerById_NotFound() {
		when(customerRepo.findByUserId("invalid_user")).thenReturn(Optional.empty());

		assertThrows(NotFoundException.class, () -> customerServiceImp.getCustomerById("invalid_user"));
	}
}