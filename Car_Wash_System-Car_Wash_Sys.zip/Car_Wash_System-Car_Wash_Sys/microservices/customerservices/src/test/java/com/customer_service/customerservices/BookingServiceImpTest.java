package com.customer_service.customerservices;

import com.customer_service.customerservices.dto.BookingDTO;
import com.customer_service.customerservices.dto.CarDetailsDTO;
import com.customer_service.customerservices.dto.WasherBookingPayloadDTO;
import com.customer_service.customerservices.entity.BookingEntity;
import com.customer_service.customerservices.entity.CarDetails;
import com.customer_service.customerservices.exceptionhandling.NotFoundException;
import com.customer_service.customerservices.repository.BookingRepo;
import com.customer_service.customerservices.repository.CarRepo;
import com.customer_service.customerservices.services.booking.BookingServiceImp;
import com.customer_service.customerservices.util.WasherClientCall;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceImpTest {

    @Mock
    private BookingRepo bookingRepo;
    @Mock
    private CarRepo carRepo;
    @Mock
    private WasherClientCall washerClientCall;
    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private BookingServiceImp bookingServiceImp;

    private BookingDTO bookingDTO;
    private BookingEntity bookingEntity;
    private CarDetails carDetails;

    @BeforeEach
    void setUp() {
        bookingDTO = new BookingDTO();
        bookingDTO.setCustomerName("John Doe");
        bookingDTO.setCustomerEmail("john@example.com");
        bookingDTO.setWashPackage("Premium");
        bookingDTO.setBookingStatus("PENDING");
        bookingDTO.setUserBookingId("BOOKID_" + UUID.randomUUID().toString().substring(0, 8));

        bookingEntity = new BookingEntity();
        bookingEntity.setCustomerName("John Doe");
        bookingEntity.setCustomerEmail("john@example.com");
        bookingEntity.setWashPackage("Premium");
        bookingEntity.setBookingStatus("PENDING");
        bookingEntity.setUserBookingId("BOOKID_12345678");
        bookingEntity.setBookingTime(LocalDateTime.now());

        carDetails = new CarDetails();
        carDetails.setCarNumber("XYZ123");
    }

    @Test
    void testBookNow_Success() {
        when(bookingRepo.save(any(BookingEntity.class))).thenReturn(bookingEntity);
        when(modelMapper.map(any(BookingEntity.class), eq(BookingDTO.class))).thenReturn(bookingDTO);
        doNothing().when(washerClientCall).sendBookingToWasherService(any(BookingDTO.class));

        BookingDTO result = bookingServiceImp.bookNow(bookingDTO, "user1", "car1", "washer1");

        assertNotNull(result);
        assertEquals("John Doe", result.getCustomerName());
        verify(bookingRepo, times(1)).save(any(BookingEntity.class));
        verify(washerClientCall, times(1)).sendBookingToWasherService(any(BookingDTO.class));
    }

    @Test
    void testGetBookingById_Success() {
        when(bookingRepo.findByUserBookingId("BOOKID_12345678")).thenReturn(Optional.of(bookingEntity));
        when(modelMapper.map(any(BookingEntity.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

        BookingDTO result = bookingServiceImp.getBookingById("BOOKID_12345678");

        assertNotNull(result);
        assertEquals("BOOKID_12345678", result.getUserBookingId());
        verify(bookingRepo, times(1)).findByUserBookingId("BOOKID_12345678");
    }

    @Test
    void testGetBookingById_NotFound() {
        when(bookingRepo.findByUserBookingId("INVALID_BOOKING")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> bookingServiceImp.getBookingById("INVALID_BOOKING"));
        verify(bookingRepo, times(1)).findByUserBookingId("INVALID_BOOKING");
    }

    @Test
    void testCancelBooking_Success() {
        when(bookingRepo.findByUserBookingId("BOOKID_12345678")).thenReturn(Optional.of(bookingEntity));
        when(washerClientCall.updateBookingStatus("BOOKID_12345678", "Cancelled")).thenReturn("Cancellation Successful");

        var response = bookingServiceImp.cancelBooking("BOOKID_12345678");

        assertNotNull(response);
        assertEquals("Booking cancelled successfully", response.get("message"));
        verify(bookingRepo, times(1)).save(any(BookingEntity.class));
        verify(washerClientCall, times(1)).updateBookingStatus("BOOKID_12345678", "Cancelled");
    }

    @Test
    void testGetAllBookings_Success() {
        when(bookingRepo.findAll()).thenReturn(List.of(bookingEntity));
        when(modelMapper.map(any(BookingEntity.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

        List<BookingDTO> result = bookingServiceImp.getAllBookings();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(bookingRepo, times(1)).findAll();
    }

    @Test
    void testSendWashRequestToWasher_Success() {
        when(bookingRepo.findByUserBookingId("BOOKID_12345678")).thenReturn(Optional.of(bookingEntity));
        when(carRepo.findByCarNumber("XYZ123")).thenReturn(Optional.of(carDetails));
        when(modelMapper.map(any(BookingEntity.class), eq(BookingDTO.class))).thenReturn(bookingDTO);
        when(modelMapper.map(any(CarDetails.class), eq(CarDetailsDTO.class))).thenReturn(new CarDetailsDTO());

        bookingServiceImp.sendWashRequestToWasher("BOOKID_12345678");

        verify(washerClientCall, times(1)).sendWashRequest(any(WasherBookingPayloadDTO.class));
    }
}