package com.customer_service.customerservices;

import com.customer_service.customerservices.dto.BookingDTO;
import com.customer_service.customerservices.entity.BookingEntity;
import com.customer_service.customerservices.exceptionhandling.NotFoundException;
import com.customer_service.customerservices.repository.BookingRepo;
import com.customer_service.customerservices.services.booking.BookingServiceImp;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.awt.print.Book;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
//import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class BookingServiceTest {
    @Autowired
    private BookingServiceImp bookingService;

    @Autowired
    private BookingRepo bookingRepository;

    @Test
    public void testSaveBooking() {
        BookingDTO bookingDTO = new BookingDTO();
        bookingDTO.setCustomerName("John Doe");
        bookingDTO.setCustomerEmail("john@example.com");
        bookingDTO.setWashPackage("Premium Wash");
        bookingDTO.setWashDate(LocalDate.now());
        bookingDTO.setWashTime(LocalTime.now());
        bookingDTO.setBookingTime(LocalDateTime.now());
        bookingDTO.setBookingStatus("PENDING");

        BookingDTO result = bookingService.bookNow(bookingDTO,"CUST_fec5e9w1","CARID_fec5e0l6","WASH_fec5e4a7");

        assertNotNull(result);
        assertEquals("John Doe", result.getCustomerName());
    }

    @Test
    public void testGetAllBooking(){
        List<BookingEntity> allBookings = bookingRepository.findAll();
        assertNotNull(allBookings);
        assertFalse(allBookings.isEmpty());
    }

    @Test
    public void testGetBookingById(){
        // Assert that NotFoundException is thrown
        assertThrows(NotFoundException.class, () -> bookingService.getBookingById("BOOKID_5632484b"));
    }

    @Test
    public void testUpdateBooking(){
        BookingDTO testBooking = new BookingDTO();
        testBooking.setUserBookingId("BOOKID_5632484b");
        testBooking.setUserId("CUST_fec5e7a5");
        testBooking.setWasherId("WASH_1ac5f0e8");
        testBooking.setCarId("CARID_902ae97e");
        testBooking.setCustomerName("Kavyansh Thakur");
        testBooking.setCustomerEmail("kav0960@gmail.com");
        testBooking.setWashPackage("Deluxe Wash");
        testBooking.setAddOns("Exterior Coating");
        testBooking.setNotes("Please clean the interior thoroughly");
        testBooking.setWashAddress("924 Church cross, Gangnam City");
        testBooking.setWashDate(LocalDate.of(2025, 7, 15));
        testBooking.setWashTime(LocalTime.of(15, 30));


        BookingDTO updatedBooking = new BookingDTO();
        updatedBooking.setWashPackage("Deluxe Wash");
        updatedBooking.setAddOns("Exterior Coating");

        String bookingId = "BOOKID_5632484b";
        assertEquals(testBooking,bookingService.updateBooking(bookingId,updatedBooking));

    }
}
