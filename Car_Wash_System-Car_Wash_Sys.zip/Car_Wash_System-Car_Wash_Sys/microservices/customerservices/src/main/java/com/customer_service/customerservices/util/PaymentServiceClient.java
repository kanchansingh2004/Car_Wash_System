package com.customer_service.customerservices.util;

import com.customer_service.customerservices.configuration.FeignClientInterceptorConfig;
import com.customer_service.customerservices.dto.PaymentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "payment-services", url = "http://localhost:8085/request/payment",configuration = FeignClientInterceptorConfig.class)
public interface PaymentServiceClient {

    @PostMapping("/process")
    PaymentDTO processPayment(@RequestParam String nonce, @RequestBody PaymentDTO dto);

    @GetMapping("/customer/{customerId}")
    List<PaymentDTO> getPaymentsByCustomer(@PathVariable String customerId);
}
