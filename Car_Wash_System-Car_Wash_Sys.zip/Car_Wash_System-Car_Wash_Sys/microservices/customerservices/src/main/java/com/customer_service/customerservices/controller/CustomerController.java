package com.customer_service.customerservices.controller;

import com.customer_service.customerservices.dto.CustomerDTO;
import com.customer_service.customerservices.dto.PaymentDTO;
import com.customer_service.customerservices.exceptionhandling.NotFoundException;
import com.customer_service.customerservices.services.customer.CustomerServiceImp;
import org.slf4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/request/customer")
public class CustomerController {
    @Autowired
    private CustomerServiceImp customerService;

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);


    //Random
    @GetMapping("/rand")
    public String hello(){
        return "Hello";
    }

    //Add user
    @PreAuthorize("hasAnyRole('CUSTOMER')")
    @PostMapping("/post")
    public String addUser(@RequestBody CustomerDTO customerDTO){
        log.info("Received request to save user for email: {}", customerDTO.getEmail());
        return customerService.addCustomer(customerDTO);
    }

    //Get all users
    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    @GetMapping("/get")
    public ResponseEntity<List<CustomerDTO>> getAllUsers(){
        log.info("Fetching all users records.");
        System.out.println("\n\n\nFetching all users records.\n\n\n");
        return ResponseEntity.ok(customerService.getAllCustomer());
    }

    //Get user by id
    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    @GetMapping("/getBy/{id}")
    public ResponseEntity<CustomerDTO> getUserById(@PathVariable String id){
        log.info("Fetching the user details with id {}", id);
        CustomerDTO userDTO = customerService.getCustomerById(id).orElseThrow(
                () -> new NotFoundException("User with ID "+ id + " Not found!!")
        );

        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }

    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    @DeleteMapping("/deleteBy/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable String id) {
        log.info("Deleting the user with id {}", id);
        customerService.deleteCustomer(id);
        return new ResponseEntity<>("User successfully deleted!", HttpStatus.OK);
    }

    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    @PutMapping("/update/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable String id, @RequestBody CustomerDTO userDTO){
        log.info("Updating the customer information with id {}", id);
        return ResponseEntity.ok(customerService.updateCustomer(id,userDTO));
    }

    // Make payment (calls Payment Service)
    @PreAuthorize("hasAnyRole('CUSTOMER')")
    @PostMapping("/make-payment")
    public ResponseEntity<PaymentDTO> makePayment(@RequestParam String nonce, @RequestBody PaymentDTO dto) {
        log.info("Received make payment request for order ID: {} and customer ID: {}", dto.getOrderId(), dto.getCustomerId());
        PaymentDTO payment = customerService.makePayment(nonce, dto);
        log.info("Payment response received with payment ID: {}", payment.getPaymentId());
        return ResponseEntity.ok(payment);
    }

    @GetMapping("/my-payments")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<List<PaymentDTO>> getMyPayments() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            log.warn("Unauthenticated access attempt");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String customerId = authentication.getPrincipal().toString();
        log.info("Fetching payment history for customer ID: {}", customerId);

        List<PaymentDTO> payments = customerService.getCustomerPayments(customerId);
        log.info("Returned {} payments for customer ID: {}", payments.size(), customerId);
        return ResponseEntity.ok(payments);
    }


}
