package com.customer_service.customerservices.services.customer;

import com.customer_service.customerservices.dto.CustomerDTO;
import com.customer_service.customerservices.dto.PaymentDTO;

import java.util.List;
import java.util.Optional;

public interface CustomerService {
    List<CustomerDTO> getAllCustomer();
    String addCustomer(CustomerDTO customerDTO);
    CustomerDTO updateCustomer(String id, CustomerDTO userDTO);
    void deleteCustomer(String id);
    Optional<CustomerDTO> getCustomerById(String id);

    PaymentDTO makePayment(String nonce, PaymentDTO dto);

    List<PaymentDTO> getCustomerPayments(String customerId);
}
