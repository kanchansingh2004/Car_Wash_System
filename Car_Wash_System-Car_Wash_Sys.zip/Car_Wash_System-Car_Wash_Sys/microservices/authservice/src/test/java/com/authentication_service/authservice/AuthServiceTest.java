package com.authentication_service.authservice;

import com.authentication_service.authservice.dto.AuthProfileDTO;
import com.authentication_service.authservice.dto.AuthUserDTO;
import com.authentication_service.authservice.dto.SignupRequest;
import com.authentication_service.authservice.entity.AuthUserEntity;
import com.authentication_service.authservice.repository.AuthUserRepo;
import com.authentication_service.authservice.service.AuthService;
import com.authentication_service.authservice.service.util.JWTUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

	@Mock
	private AuthUserRepo userRepo;

	@Mock
	private PasswordEncoder passwordEncoder;

	@Mock
	private JWTUtil jwtUtil;

	@InjectMocks
	private AuthService authService;

	private AuthUserEntity userEntity;
	private AuthUserDTO loginDTO;
	private SignupRequest signupRequest;

	@BeforeEach
	void setUp() {
		userEntity = new AuthUserEntity();
		userEntity.setUserId("CUST_" + UUID.randomUUID().toString().substring(0, 8));
		userEntity.setEmail("john@example.com");
		userEntity.setPassword("Secure@123");
		userEntity.setRole("CUSTOMER");
		userEntity.setFirstName("John");
		userEntity.setLastName("Doe");
		userEntity.setAddress("123 Main St");
		userEntity.setPhone("9876543210");

		loginDTO = new AuthUserDTO();
		loginDTO.setEmail("john@example.com");
		loginDTO.setPassword("Secure@123");

		signupRequest = new SignupRequest();
		signupRequest.setFirstName("John");
		signupRequest.setLastName("Doe");
		signupRequest.setEmail("john@example.com");
		signupRequest.setPassword("Secure@123");
		signupRequest.setRole("CUSTOMER");
		signupRequest.setAddress("123 Main St");
		signupRequest.setPhone("9876543210");
	}

	@Test
	void testRegisterUser_Success() {
		when(userRepo.findByEmail(signupRequest.getEmail())).thenReturn(Optional.empty());
		when(passwordEncoder.encode(signupRequest.getPassword())).thenReturn("encodedPassword");
		when(userRepo.save(any(AuthUserEntity.class))).thenReturn(userEntity);

		String response = authService.registerUser(signupRequest);

		assertEquals("User Registered Successfully", response);
		verify(userRepo, times(1)).save(any(AuthUserEntity.class));
	}

	@Test
	void testRegisterUser_EmailAlreadyExists() {
		when(userRepo.findByEmail(signupRequest.getEmail())).thenReturn(Optional.of(userEntity));

		String response = authService.registerUser(signupRequest);

		assertEquals("Email already exists!", response);
		verify(userRepo, never()).save(any(AuthUserEntity.class));
	}

	@Test
	void testLogin_Success() {
		when(userRepo.findByEmail(loginDTO.getEmail())).thenReturn(Optional.of(userEntity));
		when(passwordEncoder.matches(loginDTO.getPassword(), userEntity.getPassword())).thenReturn(true);
		when(jwtUtil.generateAccessToken(userEntity.getEmail(), userEntity.getRole(),userEntity.getUserId())).thenReturn("accessToken123");
		when(jwtUtil.generateRefreshToken(userEntity.getEmail())).thenReturn("refreshToken123");

		Map<String, Object> result = authService.login(loginDTO);

		assertNotNull(result);
		assertEquals("accessToken123", result.get("accessToken"));
		assertEquals("refreshToken123", result.get("refreshToken"));
		verify(userRepo, times(1)).findByEmail(loginDTO.getEmail());
	}

	@Test
	void testLogin_InvalidCredentials() {
		when(userRepo.findByEmail(loginDTO.getEmail())).thenReturn(Optional.of(userEntity));
		when(passwordEncoder.matches(loginDTO.getPassword(), userEntity.getPassword())).thenReturn(false);

		assertThrows(RuntimeException.class, () -> authService.login(loginDTO));
	}

	@Test
	void testRefreshTokens_Success() {
		when(jwtUtil.validateToken("validRefreshToken")).thenReturn(true);
		when(jwtUtil.getTokenType("validRefreshToken")).thenReturn("refresh");
		when(jwtUtil.extractClaim(eq("validRefreshToken"), any())).thenReturn(userEntity.getEmail());
		when(userRepo.findByEmail(userEntity.getEmail())).thenReturn(Optional.of(userEntity));
		when(jwtUtil.generateAccessToken(userEntity.getEmail(), userEntity.getRole(),userEntity.getUserId())).thenReturn("newAccessToken");
		when(jwtUtil.generateRefreshToken(userEntity.getEmail())).thenReturn("newRefreshToken");

		Map<String, String> response = authService.refreshTokens("validRefreshToken");

		assertNotNull(response);
		assertEquals("newAccessToken", response.get("accessToken"));
		assertEquals("newRefreshToken", response.get("refreshToken"));
		verify(userRepo, times(1)).findByEmail(userEntity.getEmail());
	}

	@Test
	void testRefreshTokens_InvalidToken() {
		when(jwtUtil.validateToken("invalidToken")).thenReturn(false);

		assertThrows(RuntimeException.class, () -> authService.refreshTokens("invalidToken"));
	}

//	@Test
//	void testResetPassword_Success() {
//		when(userRepo.findByEmail(loginDTO.getEmail())).thenReturn(Optional.of(userEntity));
//		when(passwordEncoder.encode(loginDTO.getPassword())).thenReturn("encodedPassword");
//
//		Map<String, String> response = authService.resetPassword(loginDTO);
//
//		assertEquals("Password reset successfully", response.get("Message"));
//		verify(userRepo, times(1)).save(any(AuthUserEntity.class));
//	}

//	@Test
//	void testResetPassword_UserNotFound() {
//		when(userRepo.findByEmail("unknown@example.com")).thenReturn(Optional.empty());
//
//		AuthUserDTO userDTO = new AuthUserDTO();
//		userDTO.setEmail("unknown@example.com");
//		userDTO.setPassword("NewPass123");
//
//		Map<String, String> response = authService.resetPassword(userDTO);
//
//		assertEquals("Email does not exist!", response.get("Error"));
//		verify(userRepo, never()).save(any(AuthUserEntity.class));
//	}

	@Test
	void testGetCustomerProfile_Success() {
		when(userRepo.findByEmail("john@example.com")).thenReturn(Optional.of(userEntity));

		AuthProfileDTO profile = authService.getCustomerProfile("john@example.com");

		assertNotNull(profile);
		assertEquals("John", profile.getFirstName());
		assertEquals("Doe", profile.getLastName());
	}

	@Test
	void testGetCustomerProfile_NotFound() {
		when(userRepo.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

		AuthProfileDTO profile = authService.getCustomerProfile("unknown@example.com");

		assertNull(profile);
	}
}