package com.authentication_service.authservice.service;

import com.authentication_service.authservice.dto.*;
import com.authentication_service.authservice.entity.AuthUserEntity;
import com.authentication_service.authservice.exceptionhandling.InvalidTokenException;
import com.authentication_service.authservice.repository.AuthUserRepo;
import com.authentication_service.authservice.service.util.AdminClientCall;
import com.authentication_service.authservice.service.util.CustomerClientCall;
import com.authentication_service.authservice.service.util.JWTUtil;
import com.authentication_service.authservice.service.util.WasherClientCall;
import io.jsonwebtoken.Claims;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    @Autowired private AuthUserRepo userRepo;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JWTUtil jwtUtil;
    @Autowired private CustomerClientCall customerClientCall;
    @Autowired private WasherClientCall washerClientCall;
    @Autowired private AdminClientCall adminClientCall;
    @Autowired ModelMapper modelMapper;

    public String generateId(String role) {
        String id = switch (role) {
            case "CUSTOMER" -> "CUST_" + UUID.randomUUID().toString().substring(0, 8);
            case "WASHER" -> "WASH_" + UUID.randomUUID().toString().substring(0, 8);
            case "ADMIN" -> "ADMIN_" + UUID.randomUUID().toString().substring(0, 8);
            default -> null;
        };
        logger.debug("Generated ID {} for role {}", id, role);
        return id;
    }

    public String registerUser(SignupRequest userDTO) {
        logger.info("Attempting to register user with email: {}", userDTO.getEmail());

        if (userRepo.findByEmail(userDTO.getEmail()).isPresent()) {
            logger.warn("Registration failed: Email {} already exists", userDTO.getEmail());
            return "Email already exists!";
        }

        AuthUserEntity userEntity = new AuthUserEntity();

        if (!userDTO.getFirstName().matches("^[A-Z][a-z]{2,}$")) return "Invalid name entry";
        userEntity.setFirstName(userDTO.getFirstName());

        if (!userDTO.getLastName().matches("^[A-Z][a-z]{2,}$")) return "Invalid name entry";
        userEntity.setLastName(userDTO.getLastName());

        if (!userDTO.getEmail().matches("^[A-Za-z0-9._+%-]+@[a-zA-Z0-9.-]+\\.[A-Za-z]{2,}$")) return "Invalid email entry";
        userEntity.setEmail(userDTO.getEmail());

        if (!userDTO.getPassword().matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-=+()])(?=\\S+$).{8,20}$")) {
            return "Invalid password! Please provide a valid password...";
        }
        userEntity.setPassword(passwordEncoder.encode(userDTO.getPassword()));

        String role = userDTO.getRole();
        if (!role.matches("CUSTOMER|ADMIN|WASHER")) return "Invalid identity";
        userEntity.setRole(role);

        if (!userDTO.getAddress().matches("^[A-Za-z0-9-., ]+$")) return "Provide a valid address!!";
        userEntity.setAddress(userDTO.getAddress());

        if (!userDTO.getPhone().matches("^[0-9]{10}$")) return "Contact number is invalid";
        userEntity.setPhone(userDTO.getPhone());

        String userId = generateId(role);
        if (userId == null || userId.isEmpty()) return "Not a valid user!!";
        userEntity.setUserId(userId);

        userRepo.save(userEntity);

        if(role.equals("CUSTOMER")) {
            storeUserInCustomerService(userEntity);
        }else if(role.equals("WASHER")){
            storeUserInWasherService(userEntity);
        }else if(role.equals("ADMIN")){
            storeUserInAdminService(userEntity);
        }

        logger.info("User registered successfully with ID: {}", userId);
        return "User Registered Successfully";
    }

    private void storeUserInAdminService(AuthUserEntity userEntity) {
        logger.info("Admin {} forwarded to admin-service", userEntity.getEmail());
        String result = adminClientCall.addUser(modelMapper.map(userEntity, AdminDTO.class));

        logger.info("Adding status to Admin service: " + result);
    }

    private void storeUserInCustomerService(AuthUserEntity userEntity) {
        logger.info("Customer {} forwarded to customer-service", userEntity.getEmail());
        String result = customerClientCall.addUser(modelMapper.map(userEntity, CustomerDTO.class));

        logger.info("Adding status to customer service: " + result);
    }

    private void storeUserInWasherService(AuthUserEntity userEntity) {
        logger.info("Washer {} forwarded to washer-service", userEntity.getEmail());
        String result = washerClientCall.addUser(modelMapper.map(userEntity, WasherDTO.class));

        logger.info("Adding status to washer service: " + result);
    }

    public Map<String, Object> login(AuthUserDTO userDTO) {
        logger.info("Login attempt for email: {}", userDTO.getEmail());
        AuthUserEntity user = userRepo.findByEmail(userDTO.getEmail())
                .orElseThrow(() -> {
                    logger.warn("Login failed: user {} not found", userDTO.getEmail());
                    return new RuntimeException("User not found");
                });

        if (!passwordEncoder.matches(userDTO.getPassword(), user.getPassword())) {
            logger.warn("Login failed: invalid password for {}", userDTO.getEmail());
            throw new RuntimeException("Invalid credentials");
        }

        logger.info("Login successful for user: {}", userDTO.getEmail());
        return Map.of(
                "accessToken", jwtUtil.generateAccessToken(user.getEmail(), user.getRole(),user.getUserId()),
                "refreshToken", jwtUtil.generateRefreshToken(user.getEmail()),
                "expiresIn", TimeUnit.MILLISECONDS.toSeconds(JWTUtil.ACCESS_TOKEN_EXPIRE_TIME),
                "user", Map.of(
                        "message", "Login successful",
                        "email", user.getEmail(),
                        "role", user.getRole(),
                        "firstName", user.getFirstName(),
                        "lastName", user.getLastName(),
                        "User ID", user.getUserId()
                )
        );
    }

    public Map<String, String> refreshTokens(String refreshToken) {
        logger.debug("Refresh token request received");

        if (!jwtUtil.validateToken(refreshToken)) {
            logger.warn("Refresh failed: token validation failed");
            throw new RuntimeException("Invalid refresh token");
        }

        if (!"refresh".equals(jwtUtil.getTokenType(refreshToken))) {
            logger.warn("Refresh failed: incorrect token type");
            throw new RuntimeException("Not a refresh token");
        }

        String email = jwtUtil.extractClaim(refreshToken, Claims::getSubject);
        AuthUserEntity user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        logger.info("Refresh token granted for user: {}", email);
        return Map.of(
                "accessToken", jwtUtil.generateAccessToken(email, user.getRole(),user.getUserId()),
                "refreshToken", jwtUtil.generateRefreshToken(email)
        );
    }

    public Map<String, String> resetPassword(String token, AuthUserDTO dto) {
        logger.info("Password reset attempt for email: {}", dto.getEmail());

        if (!jwtUtil.validateToken(token)) {
            logger.warn("Reset failed: invalid token");
            throw new InvalidTokenException("Token Not Validate");
        }

        Optional<AuthUserEntity> optionalUser = userRepo.findByEmail(dto.getEmail().trim());
        if (optionalUser.isEmpty()) {
            logger.warn("Reset failed: no user found for email {}", dto.getEmail());
            return Map.of("Error", "Email does not exist!");
        }

        AuthUserEntity entity = optionalUser.get();
        entity.setPassword(passwordEncoder.encode(dto.getPassword()));
        userRepo.save(entity);

        logger.info("Password reset successful for {}", dto.getEmail());
        return Map.of("Message", "Password reset successfully");
    }

    public AuthProfileDTO getCustomerProfile(String email) {
        return getProfileByRole(email, "CUSTOMER");
    }

    public AuthProfileDTO getWasherProfile(String email) {
        return getProfileByRole(email, "WASHER");
    }

    public AuthProfileDTO getAdminProfile(String email) {
        return getProfileByRole(email, "ADMIN");
    }

    private AuthProfileDTO getProfileByRole(String email, String role) {
        logger.debug("Fetching {} profile for {}", role.toLowerCase(), email);
        Optional<AuthUserEntity> optionalUser = userRepo.findByEmail(email);
        if (optionalUser.isEmpty()) {
            logger.warn("No user found for {}", email);
            return null;
        }

        AuthUserEntity entity = optionalUser.get();
        if (!role.equalsIgnoreCase(entity.getRole())) {
            logger.warn("User role mismatch: expected {}, got {}", role, entity.getRole());
            return null;
        }

        logger.info("{} profile fetched for {}", role, email);
        AuthProfileDTO dto = new AuthProfileDTO();
        dto.setFirstName(entity.getFirstName());
        dto.setLastName(entity.getLastName());
        dto.setRole(entity.getRole());
        dto.setEmail(entity.getEmail());
        dto.setAddress(entity.getAddress());
        dto.setPhone(entity.getPhone());
        dto.setUserId(entity.getUserId());
        return dto;
    }
}