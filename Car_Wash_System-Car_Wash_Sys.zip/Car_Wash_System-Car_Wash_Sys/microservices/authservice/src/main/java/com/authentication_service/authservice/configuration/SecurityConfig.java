package com.authentication_service.authservice.configuration;

import com.authentication_service.authservice.filter.JwtAuthFilter;
import com.authentication_service.authservice.service.util.JWTUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    private JWTUtil jwtUtil;

    @Bean
    public PasswordEncoder passwordEncoder() {
        logger.info("Creating PasswordEncoder bean using BCrypt");
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        logger.info("Initializing SecurityFilterChain");

        http.csrf(AbstractHttpConfigurer::disable);
        logger.debug("CSRF protection disabled");

        http.authorizeHttpRequests(auth -> {
            auth.requestMatchers(
                    "/request/auth/login",
                    "/request/auth/refresh",
                    "/request/auth/signup",
                    "/request/auth/resetPassword",
                    "/request/auth/customer/getProfile*",
                    "/request/customer/post*",
                    "/request/washer/post*",
                    "/request/auth/washer/getProfile*",
                    "/request/auth/admin/getProfile*"
            ).permitAll();
            logger.debug("Configured public endpoints");
//
//            auth.requestMatchers("/request/auth/**").hasAnyAuthority("ADMIN", "CUSTOMER", "WASHER");
//            logger.debug("Configured role-based access control for /request/auth/**");

            auth.anyRequest().authenticated();
            logger.debug("Configured authentication requirement for all other endpoints");
        });

        http.addFilterBefore(new JwtAuthFilter(jwtUtil), UsernamePasswordAuthenticationFilter.class);
        logger.info("JwtAuthFilter added to filter chain before UsernamePasswordAuthenticationFilter");

        logger.info("SecurityFilterChain initialized successfully");
        return http.build();
    }
}