package com.authentication_service.authservice.exceptionhandling;

public class InvalidTokenException extends RuntimeException{
    public InvalidTokenException(String message){
        super(message);
    }
}
