package com.authentication_service.authservice.filter;

import com.authentication_service.authservice.service.util.JWTUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class JwtAuthFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthFilter.class);
    private final JWTUtil jwtUtil;

    public JwtAuthFilter(JWTUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        List<String> openEndpoints = List.of(
                "/request/auth/signup",
                "/request/auth/login",
                "/request/auth/refresh"
        );

        boolean isPublic = openEndpoints.stream().anyMatch(path::startsWith);
        if (isPublic) {
            logger.debug("Skipping JWT filter for public endpoint: {}", path);
        }
        return isPublic;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws IOException, ServletException {

        String header = request.getHeader("Authorization");
        String path = request.getRequestURI();

        if (header == null || !header.startsWith("Bearer ")) {
            logger.debug("No Authorization header or token missing for request: {}", path);
            filterChain.doFilter(request, response);
            return;
        }

        String token = header.substring(7);
        if (!jwtUtil.validateToken(token) || !"access".equals(jwtUtil.getTokenType(token))) {
            logger.warn("Unauthorized access attempt to {} — invalid or non-access token", path);
            response.sendError(HttpStatus.UNAUTHORIZED.value(), "Invalid token");
            return;
        }

        String email = jwtUtil.extractClaim(token, Claims::getSubject);
        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(email, null, Collections.emptyList());

        SecurityContextHolder.getContext().setAuthentication(auth);
        logger.debug("User {} authenticated for path {}", email, path);

        filterChain.doFilter(request, response);
    }
}