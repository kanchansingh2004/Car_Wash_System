package com.authentication_service.authservice.service.util;

import com.authentication_service.authservice.dto.WasherDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "washer-services", url = "http://localhost:8060")
public interface WasherClientCall {
    @PostMapping("/request/washer/post")
    String addUser(@RequestBody WasherDTO washerDTO);
}
