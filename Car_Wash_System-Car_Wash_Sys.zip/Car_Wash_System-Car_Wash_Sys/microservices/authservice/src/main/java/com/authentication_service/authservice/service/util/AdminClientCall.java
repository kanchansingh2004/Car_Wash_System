package com.authentication_service.authservice.service.util;

import com.authentication_service.authservice.dto.AdminDTO;
import com.authentication_service.authservice.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "admin-services", url = "http://localhost:8090")
public interface AdminClientCall {
    @PostMapping("/request/admin/post")
    String addUser(AdminDTO adminDTO);
}