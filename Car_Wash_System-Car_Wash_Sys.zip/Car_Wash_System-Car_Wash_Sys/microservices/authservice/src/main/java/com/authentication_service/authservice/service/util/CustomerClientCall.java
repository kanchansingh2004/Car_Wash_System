package com.authentication_service.authservice.service.util;

import com.authentication_service.authservice.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "customer-services", url = "http://localhost:8020")
public interface CustomerClientCall {
    @PostMapping("/request/customer/post")
    String addUser(CustomerDTO customerDTO);
}

