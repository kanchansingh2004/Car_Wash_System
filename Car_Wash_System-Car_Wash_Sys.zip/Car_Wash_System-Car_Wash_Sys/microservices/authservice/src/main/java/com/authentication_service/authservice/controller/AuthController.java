package com.authentication_service.authservice.controller;

import com.authentication_service.authservice.dto.*;
import com.authentication_service.authservice.service.AuthService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/request/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthService authService;

    // Register new user
    @PostMapping("/signup")
    public Map<String, String> registerUser(@RequestBody SignupRequest userDTO) {
        logger.info("Received signup request for email: {}", userDTO.getEmail());
        String message = authService.registerUser(userDTO);
        logger.info("Signup completed: {}", message);
        return Map.of("Message", message);
    }

    // User login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthUserDTO userDTO) {
        logger.info("Login attempt for email: {}", userDTO.getEmail());
        try {
            var response = authService.login(userDTO);
            logger.info("Login successful for: {}", userDTO.getEmail());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            logger.warn("Login failed for {}: {}", userDTO.getEmail(), e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

    // Token refresh
    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody Map<String, String> request) {
        String refreshToken = request.get("refreshToken");
        logger.info("Refresh token request received");
        try {
            var response = authService.refreshTokens(refreshToken);
            logger.info("Token refresh successful");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            logger.warn("Token refresh failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

    // Reset password
    @PutMapping("/resetPassword")
    public Map<String, String> resetPassword(@RequestParam String token, @RequestBody AuthUserDTO dto) {
        logger.info("Password reset requested for token: {}", token);
        Map<String, String> result = authService.resetPassword(token, dto);
        logger.info("Password reset status: {}", result.get("status"));
        return result;
    }

    // Get customer profile
    @GetMapping("/customer/getProfile")
    public ResponseEntity<?> getCustomerProfile(@RequestParam String email) {
        logger.info("Fetching customer profile for email: {}", email);
        AuthProfileDTO profile = authService.getCustomerProfile(email);
        if (profile == null) {
            logger.warn("Customer profile not found for email: {}", email);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Customer not found or not a valid customer"));
        }
        logger.info("Customer profile found for email: {}", email);
        return ResponseEntity.ok(profile);
    }

    // Get washer profile
    @GetMapping("/washer/getProfile")
    public ResponseEntity<?> getWasherProfile(@RequestParam String email) {
        logger.info("Fetching washer profile for email: {}", email);
        AuthProfileDTO profile = authService.getWasherProfile(email);
        if (profile == null) {
            logger.warn("Washer profile not found for email: {}", email);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Washer not found or not a valid washer"));
        }
        logger.info("Washer profile found for email: {}", email);
        return ResponseEntity.ok(profile);
    }

    // Get admin profile
    @GetMapping("/admin/getProfile")
    public ResponseEntity<?> getAdminProfile(@RequestParam String email) {
        logger.info("Fetching admin profile for email: {}", email);
        AuthProfileDTO profile = authService.getAdminProfile(email);
        if (profile == null) {
            logger.warn("Admin profile not found for email: {}", email);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Admin not found or not a valid admin"));
        }
        logger.info("Admin profile found for email: {}", email);
        return ResponseEntity.ok(profile);
    }
}