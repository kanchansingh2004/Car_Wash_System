package com.paymentservices.payment_service.service;

import com.braintreegateway.*;
import com.paymentservices.payment_service.dto.PaymentDTO;
import com.paymentservices.payment_service.entity.PaymentEntity;
import com.paymentservices.payment_service.globalexception.NotFoundException;
import com.paymentservices.payment_service.repository.PaymentRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    @Autowired
    private BraintreeGateway braintreeGateway;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ModelMapper modelMapper;

    public PaymentDTO processPayment(String nonce, PaymentDTO dto) {
        log.info("Processing payment for order ID: {}, customer ID: {}", dto.getOrderId(), dto.getCustomerId());

        TransactionRequest request = new TransactionRequest()
                .amount(BigDecimal.valueOf(dto.getAmount()))
                .paymentMethodNonce(nonce)
                .options().submitForSettlement(true).done();

        Result<Transaction> result = braintreeGateway.transaction().sale(request);

        if (result.isSuccess()) {
            Transaction transaction = result.getTarget();
            dto.setPaymentId(transaction.getId());
            dto.setPaymentStatus(transaction.getStatus().toString());
            dto.setPaymentDate(LocalDateTime.now());

            PaymentEntity entity = modelMapper.map(dto, PaymentEntity.class);
            paymentRepository.save(entity);

            log.info("Payment processed successfully for order ID: {} with payment ID: {}", dto.getOrderId(), dto.getPaymentId());
            return dto;
        } else {
            log.error("Payment failed for order ID: {}. Error: {}", dto.getOrderId(), result.getMessage());
            throw new RuntimeException("Payment Failed: " + result.getMessage());
        }
    }

    public PaymentDTO getPaymentDetails(String paymentId) {
        log.info("Fetching payment details for payment ID: {}", paymentId);
        Optional<PaymentEntity> paymentEntity = paymentRepository.findById(Long.valueOf(paymentId));

        if (paymentEntity.isEmpty()) {
            log.warn("Payment not found with ID: {}", paymentId);
            throw new NotFoundException("Payment not found with ID: " + paymentId);
        }

        log.info("Payment details retrieved successfully for ID: {}", paymentId);
        return modelMapper.map(paymentEntity.get(), PaymentDTO.class);
    }

    public List<PaymentDTO> getPaymentsByCustomer(String customerId) {
        log.info("Fetching payments for customer ID: {}", customerId);
        List<PaymentEntity> payments = paymentRepository.findByCustomerId(customerId);

        if (payments.isEmpty()) {
            log.warn("No payments found for customer ID: {}", customerId);
            throw new NotFoundException("No payments found for customer ID: " + customerId);
        }

        log.info("Retrieved {} payments for customer ID: {}", payments.size(), customerId);
        return payments.stream()
                .map(payment -> modelMapper.map(payment, PaymentDTO.class))
                .collect(Collectors.toList());
    }

    public List<PaymentDTO> getAllPayments() {
        log.info("Fetching all payments");

        List<PaymentEntity> payments = paymentRepository.findAll();

        if (payments.isEmpty()) {
            log.warn("No payments found in the database");
            throw new NotFoundException("No payments found");
        }

        log.info("Retrieved {} total payments", payments.size());
        return payments.stream()
                .map(payment -> modelMapper.map(payment, PaymentDTO.class))
                .collect(Collectors.toList());
    }

    public String generateClientToken() {
        log.info("Generating client token for payment processing.");
        return braintreeGateway.clientToken().generate();
    }

    public void updatePendingPayments() {
        List<PaymentEntity> pendingPayments = paymentRepository.findByPaymentStatus("Submitted For Settlement");

        for (PaymentEntity payment : pendingPayments) {
            try {
                Transaction txn = braintreeGateway.transaction().find(payment.getPaymentGatewayTxnId());
                String status = txn.getStatus().toString();

                if ("SETTLED".equalsIgnoreCase(status)) {
                    log.info("Updating payment {} to status {}", payment.getPaymentId(), status);
                    payment.setPaymentStatus("Settled");
                    paymentRepository.save(payment);
                } else {
                    log.info("Payment {} is still in status {}", payment.getPaymentId(), status);
                }

            } catch (Exception e) {
                log.error("Failed to fetch status for payment {}", payment.getPaymentId(), e);
            }
        }
    }
}