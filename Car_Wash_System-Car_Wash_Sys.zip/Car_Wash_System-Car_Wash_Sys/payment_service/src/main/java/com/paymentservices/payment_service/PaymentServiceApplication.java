package com.paymentservices.payment_service;

import com.paymentservices.payment_service.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@SpringBootApplication
@EnableDiscoveryClient
@EnableScheduling
@Slf4j
public class PaymentServiceApplication {

	@Autowired
	private PaymentService paymentService;
	public static void main(String[] args) {
		SpringApplication.run(PaymentServiceApplication.class, args);
	}

	@Scheduled(fixedDelay = 10 * 60 * 1000) // Every 10 minutes
	public void scheduledStatusCheck() {
		log.info("Running scheduled status update check");
		paymentService.updatePendingPayments();
	}
}
