package com.paymentservices.payment_service.controller;

import com.paymentservices.payment_service.dto.PaymentDTO;
import com.paymentservices.payment_service.service.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/request/payment")
public class PaymentController {

    private static final Logger log = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentService paymentService;

    // Process a new payment - Accessible by CUSTOMER
    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping("/process")
    public ResponseEntity<PaymentDTO> processPayment(@RequestParam String nonce, @RequestBody PaymentDTO dto) {
        log.info("Received payment request for order ID: {}, customer ID: {}", dto.getOrderId(), dto.getCustomerId());
        PaymentDTO processedPayment = paymentService.processPayment(nonce, dto);
        log.info("Payment successfully processed for order ID: {} with payment ID: {}", dto.getOrderId(), processedPayment.getPaymentId());
        return ResponseEntity.ok(processedPayment);
    }

    // Generate Braintree client token - Accessible by CUSTOMER
    @PreAuthorize("hasRole('CUSTOMER')")
    @GetMapping("/client-token")
    public ResponseEntity<String> generateClientToken() {
        log.info("Request received for generating client token.");
        String clientToken = paymentService.generateClientToken();
        log.info("Client token generated successfully.");
        return ResponseEntity.ok(clientToken);
    }

    // Get payment details by payment ID - Accessible by ADMIN and CUSTOMER
    @PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')")
    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentDTO> getPaymentDetails(@PathVariable String paymentId) {
        log.info("Fetching payment details for ID: {}", paymentId);
        PaymentDTO paymentDetails = paymentService.getPaymentDetails(paymentId);
        log.info("Payment details retrieved for ID: {}", paymentId);
        return ResponseEntity.ok(paymentDetails);
    }

    // Get all payments made by a specific customer - Accessible by ADMIN and the CUSTOMER themselves
    @PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByCustomer(@PathVariable String customerId) {
        log.info("Fetching all payments for customer ID: {}", customerId);
        List<PaymentDTO> payments = paymentService.getPaymentsByCustomer(customerId);
        log.info("Retrieved {} payments for customer ID: {}", payments.size(), customerId);
        return ResponseEntity.ok(payments);
    }

    // Get all payment records - Accessible only by ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/getAll")
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
        log.info("API called: Get all payments");
        List<PaymentDTO> payments = paymentService.getAllPayments();
        return ResponseEntity.ok(payments);
    }


    @PostMapping("/refresh-status")
    public ResponseEntity<String> refreshStatuses() {
        paymentService.updatePendingPayments();
        return ResponseEntity.ok("Status check completed.");
    }

}
