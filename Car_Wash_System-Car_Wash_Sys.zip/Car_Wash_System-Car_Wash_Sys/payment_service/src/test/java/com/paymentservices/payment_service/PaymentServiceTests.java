package com.paymentservices.payment_service;

import com.braintreegateway.*;

import com.paymentservices.payment_service.dto.PaymentDTO;

import com.paymentservices.payment_service.entity.PaymentEntity;

import com.paymentservices.payment_service.globalexception.NotFoundException;

import com.paymentservices.payment_service.repository.PaymentRepository;

import com.paymentservices.payment_service.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.junit.jupiter.MockitoExtension;

import org.modelmapper.ModelMapper;

import java.math.BigDecimal;

import java.time.LocalDateTime;

import java.util.List;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)

class PaymentServiceTest {

	@Mock

	private BraintreeGateway braintreeGateway;

	@Mock

	private PaymentRepository paymentRepository;

	@Mock

	private ModelMapper modelMapper;

	@InjectMocks

	private PaymentService paymentService;

	private PaymentDTO paymentDTO;

	private PaymentEntity paymentEntity;

	private TransactionRequest transactionRequest;

	private Result<Transaction> transactionResult;

	private Transaction transaction;

	@BeforeEach

	void setUp() {

		paymentDTO = new PaymentDTO();

		paymentDTO.setOrderId("ORDER123");

		paymentDTO.setCustomerId("CUST123");

		paymentDTO.setAmount(150.75);

		paymentDTO.setPaymentStatus("SETTLED");

		paymentEntity = new PaymentEntity();

		paymentEntity.setOrderId("ORDER123");

		paymentEntity.setCustomerId("CUST123");

		paymentEntity.setAmount(150.75);

		paymentEntity.setPaymentStatus("SETTLED");

		paymentEntity.setPaymentDate(LocalDateTime.now());

		transactionRequest = new TransactionRequest()

				.amount(BigDecimal.valueOf(paymentDTO.getAmount()))

				.paymentMethodNonce("fake-nonce")

				.options().submitForSettlement(true).done();

		transaction = mock(Transaction.class);

		when(transaction.getId()).thenReturn("PAY123");

		when(transaction.getStatus()).thenReturn(Transaction.Status.SETTLED);

		transactionResult = mock(Result.class);

		when(transactionResult.isSuccess()).thenReturn(true);

		when(transactionResult.getTarget()).thenReturn(transaction);

	}

	@Test

	void testProcessPayment_Success() {

		when(braintreeGateway.transaction().sale(any(TransactionRequest.class))).thenReturn(transactionResult);

		when(modelMapper.map(any(PaymentDTO.class), eq(PaymentEntity.class))).thenReturn(paymentEntity);

		when(paymentRepository.save(any(PaymentEntity.class))).thenReturn(paymentEntity);

		PaymentDTO result = paymentService.processPayment("fake-nonce", paymentDTO);

		assertNotNull(result);

		assertEquals("PAY123", result.getPaymentId());

		assertEquals("SETTLED", result.getPaymentStatus());

		verify(paymentRepository, times(1)).save(any(PaymentEntity.class));

	}

	@Test

	void testProcessPayment_Failure() {

		when(transactionResult.isSuccess()).thenReturn(false);

		when(transactionResult.getMessage()).thenReturn("Insufficient funds");

		when(braintreeGateway.transaction().sale(any(TransactionRequest.class))).thenReturn(transactionResult);

		assertThrows(RuntimeException.class, () -> paymentService.processPayment("fake-nonce", paymentDTO));

	}

	@Test

	void testGetPaymentDetails_Success() {

		when(paymentRepository.findById(1L)).thenReturn(Optional.of(paymentEntity));

		when(modelMapper.map(any(PaymentEntity.class), eq(PaymentDTO.class))).thenReturn(paymentDTO);

		PaymentDTO result = paymentService.getPaymentDetails("1");

		assertNotNull(result);

		assertEquals("ORDER123", result.getOrderId());

		verify(paymentRepository, times(1)).findById(1L);

	}

	@Test

	void testGetPaymentDetails_NotFound() {

		when(paymentRepository.findById(99L)).thenReturn(Optional.empty());

		assertThrows(NotFoundException.class, () -> paymentService.getPaymentDetails("99"));

	}

	@Test

	void testGetPaymentsByCustomer_Success() {

		when(paymentRepository.findByCustomerId("CUST123")).thenReturn(List.of(paymentEntity));

		when(modelMapper.map(any(PaymentEntity.class), eq(PaymentDTO.class))).thenReturn(paymentDTO);

		List<PaymentDTO> result = paymentService.getPaymentsByCustomer("CUST123");

		assertNotNull(result);

		assertEquals(1, result.size());

		assertEquals("ORDER123", result.get(0).getOrderId());

		verify(paymentRepository, times(1)).findByCustomerId("CUST123");

	}

	@Test

	void testGetPaymentsByCustomer_NotFound() {

		when(paymentRepository.findByCustomerId("INVALID_CUST")).thenReturn(List.of());

		assertThrows(NotFoundException.class, () -> paymentService.getPaymentsByCustomer("INVALID_CUST"));

	}

	@Test

	void testGenerateClientToken_Success() {

		when(braintreeGateway.clientToken().generate()).thenReturn("mock-client-token");

		String token = paymentService.generateClientToken();

		assertNotNull(token);

		assertEquals("mock-client-token", token);

	}

}

