package com.invoiceservice.invoice_service.controller;

import com.invoiceservice.invoice_service.entity.Invoice;
import com.invoiceservice.invoice_service.service.InvoiceService;
import com.invoiceservice.invoice_service.service.PdfGeneratorService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final PdfGeneratorService pdfGeneratorService;

    public InvoiceController(InvoiceService invoiceService, PdfGeneratorService pdfGeneratorService) {
        this.invoiceService = invoiceService;
        this.pdfGeneratorService = pdfGeneratorService;
    }

    // Create a new invoice
    @PostMapping("/generate")
    public ResponseEntity<Invoice> createInvoice(@RequestBody Invoice invoice) {
        Invoice savedInvoice = invoiceService.generateInvoice(invoice);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedInvoice);
    }

    // Get invoice by ID
    @GetMapping("/{invoiceId}")
    public ResponseEntity<Invoice> getInvoiceById(@PathVariable String invoiceId) {
        Invoice invoice = invoiceService.getInvoiceByInvoiceId(invoiceId);
        return ResponseEntity.ok(invoice);
    }

    // Get invoices by user ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Invoice>> getInvoicesByUserId(@PathVariable String userId) {
        List<Invoice> invoices = invoiceService.getInvoicesByUserId(userId);
        return ResponseEntity.ok(invoices);
    }

    // Get invoices by washer ID
    @GetMapping("/washer/{washerId}")
    public ResponseEntity<List<Invoice>> getInvoicesByWasherId(@PathVariable String washerId) {
        List<Invoice> invoices = invoiceService.getInvoicesByWasherId(washerId);
        return ResponseEntity.ok(invoices);
    }

    // Download invoice PDF
    @GetMapping("/{invoiceId}/pdf")
    public ResponseEntity<byte[]> downloadInvoicePdf(@PathVariable String invoiceId) {
        Invoice invoice = invoiceService.getInvoiceByInvoiceId(invoiceId);
        byte[] pdfData = pdfGeneratorService.generateBillPdf(invoice);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=invoice_" + invoiceId + ".pdf");
        headers.add("Content-Type", "application/pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfData);
    }
}