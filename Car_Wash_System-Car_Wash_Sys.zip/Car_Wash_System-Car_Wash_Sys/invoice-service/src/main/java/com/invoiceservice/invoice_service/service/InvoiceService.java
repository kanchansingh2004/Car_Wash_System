package com.invoiceservice.invoice_service.service;

import com.invoiceservice.invoice_service.entity.Invoice;
import com.invoiceservice.invoice_service.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository repository;

    @Autowired
    private PdfGeneratorService pdfService;

    // Generate and save an invoice
    public Invoice generateInvoice(Invoice invoice) {
        invoice.setInvoiceId(generateUniqueInvoiceId());
        invoice.setInvoiceTimestamp(LocalDateTime.now());

        Invoice savedInvoice = repository.save(invoice);

        // Generate PDF after invoice creation
        byte[] pdfData = pdfService.generateBillPdf(savedInvoice);
        System.out.println("PDF generated successfully for Invoice ID: " + savedInvoice.getInvoiceId());

        return savedInvoice;
    }

    // Fetch invoice by ID
    public Invoice getInvoiceByInvoiceId(String invoiceId) {
        return repository.findByInvoiceId(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found for ID: " + invoiceId));
    }

    // Fetch invoices by user ID
    public List<Invoice> getInvoicesByUserId(String userId) {
        return repository.findByUserId(userId); // Fixed method name
    }

    // Fetch invoices by washer ID
    public List<Invoice> getInvoicesByWasherId(String washerId) {
        return repository.findByWasherId(washerId); // Fixed method name
    }

    // Generate a unique invoice ID
    private String generateUniqueInvoiceId() {
        String invoiceId;
        do {
            invoiceId = "INV" + (int) (Math.random() * 9000 + 1000);
        } while (repository.findByInvoiceId(invoiceId).isPresent()); // Works correctly now
        return invoiceId;
    }
}