package com.invoiceservice.invoice_service.service;

import com.invoiceservice.invoice_service.entity.Invoice;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

@Service
public class PdfGeneratorService {
    public byte[] generateBillPdf(Invoice invoice) {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(outputStream);
            PdfDocument pdfDocument = new PdfDocument(writer);
            Document document = new Document(pdfDocument);

            document.add(new Paragraph("Invoice")
                    .setBold()
                    .setFontSize(20)
                    .setMarginBottom(20));

            // Table setup
            Table table = new Table(new float[]{3, 3});
            table.setWidth(com.itextpdf.layout.properties.UnitValue.createPercentValue(100));

            table.addCell(new Cell().add(new Paragraph("Invoice ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getInvoiceId())));

            table.addCell(new Cell().add(new Paragraph("Transaction ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getTransId())));

            table.addCell(new Cell().add(new Paragraph("Order ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getOrderId())));

            table.addCell(new Cell().add(new Paragraph("Payment ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getPaymentId())));

            table.addCell(new Cell().add(new Paragraph("User ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getUserId())));

            table.addCell(new Cell().add(new Paragraph("Washer ID:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getWasherId())));

            table.addCell(new Cell().add(new Paragraph("Add-ons:")));
            table.addCell(new Cell().add(new Paragraph(String.join(", ", invoice.getAddOns()))));

            table.addCell(new Cell().add(new Paragraph("Package Details:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getPackageDetails())));

            table.addCell(new Cell().add(new Paragraph("After Wash Image:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getAfterWashImage())));

            table.addCell(new Cell().add(new Paragraph("Amount:")));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(invoice.getAmount()))));

            table.addCell(new Cell().add(new Paragraph("Invoice Timestamp:")));
            table.addCell(new Cell().add(new Paragraph(invoice.getInvoiceTimestamp().toString())));

            document.add(table);
            document.close();

            return outputStream.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Error while generating PDF", e);
        }
    }
}
